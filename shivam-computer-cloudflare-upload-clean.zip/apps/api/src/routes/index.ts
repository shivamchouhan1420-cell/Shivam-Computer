import { Router } from "express";
import { Admission } from "../models/Admission.js";
import { Content } from "../models/Content.js";
import { Course } from "../models/Course.js";
import { LoginHistory } from "../models/LoginHistory.js";
import { Message } from "../models/Message.js";
import { Order } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { User } from "../models/User.js";
import { authRoutes } from "./auth.routes.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { crudController } from "../controllers/resource.controller.js";
import { admissionReceipt, createAdmission, exportAdmissions } from "../controllers/admission.controller.js";
import { createOrder, exportOrders } from "../controllers/order.controller.js";
import { analytics } from "../controllers/dashboard.controller.js";
import { upload } from "../middleware/upload.js";
import { uploadFile } from "../controllers/upload.controller.js";

export const apiRoutes = Router();

apiRoutes.get("/health", (_req, res) => res.json({ status: "ok" }));
apiRoutes.use("/auth", authRoutes);

resource(apiRoutes, "/products", Product, true);
resource(apiRoutes, "/courses", Course, true);
resource(apiRoutes, "/content", Content, true);
apiRoutes.post("/messages", crudController(Message).create);
resource(apiRoutes, "/messages", Message, false);

apiRoutes.post("/admissions", createAdmission);
apiRoutes.get("/admissions/export", authenticate, authorize("admin"), exportAdmissions);
apiRoutes.get("/admissions/:id/receipt", authenticate, admissionReceipt);
resource(apiRoutes, "/admissions", Admission, true);

apiRoutes.post("/orders", authenticate, createOrder);
apiRoutes.get("/orders/export", authenticate, authorize("admin"), exportOrders);
resource(apiRoutes, "/orders", Order, true);

resource(apiRoutes, "/users", User, true);
resource(apiRoutes, "/login-records", LoginHistory, true);

apiRoutes.get("/admin/analytics", authenticate, authorize("admin"), analytics);
apiRoutes.post("/admin/backup", authenticate, authorize("admin"), (_req, res) => res.json({ message: "Backup job accepted", at: new Date() }));
apiRoutes.post("/admin/restore", authenticate, authorize("admin"), (_req, res) => res.json({ message: "Restore job accepted", at: new Date() }));
apiRoutes.post("/admin/upload", authenticate, authorize("admin"), upload.single("file"), uploadFile);
apiRoutes.get("/student/dashboard", authenticate, authorize("user", "admin"), (_req, res) => res.json({ profile: true, admissionStatus: true, courseDetails: true, studyMaterial: [], attendance: [], assignments: [], exams: [], result: [], certificate: [], feeStatus: true, paymentHistory: [] }));

function resource(router: Router, path: string, model: any, publicRead: boolean) {
  const c = crudController(model);
  const adminGuards = [authenticate, authorize("admin")] as const;
  const readGuards = publicRead ? [] : adminGuards;
  router.get(path, ...readGuards, c.list);
  router.get(`${path}/:idOrSlug`, ...readGuards, c.get);
  router.post(path, ...adminGuards, c.create);
  router.patch(`${path}/:id`, ...adminGuards, c.update);
  router.delete(`${path}/:id`, ...adminGuards, c.remove);
}
