import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import { adminLogin, forgotPassword, login, me, register, resetPassword } from "../controllers/auth.controller.js";

export const authRoutes = Router();

authRoutes.post("/register", register);
authRoutes.post("/login", login);
authRoutes.post("/admin/login", adminLogin);
authRoutes.post("/forgot-password", forgotPassword);
authRoutes.post("/reset-password", resetPassword);
authRoutes.get("/me", authenticate, me);
