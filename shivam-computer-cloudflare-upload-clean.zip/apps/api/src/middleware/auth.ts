import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { isOnlyAdminEmail } from "../config/admin.js";
import { env } from "../config/env.js";
import { User } from "../models/User.js";

export type AuthRole = "user" | "admin";

declare global {
  namespace Express {
    interface Request {
      user?: { id: string; role: AuthRole; email: string };
    }
  }
}

export async function authenticate(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const token = header?.startsWith("Bearer ") ? header.slice(7) : req.cookies?.token;
  if (!token) return res.status(401).json({ message: "Authentication required" });
  try {
    const decoded = jwt.verify(token, env.jwtSecret) as { id: string };
    const user = await User.findById(decoded.id);
    if (!user) return res.status(401).json({ message: "Invalid token" });
    req.user = { id: String(user._id), role: user.role as AuthRole, email: user.email };
    next();
  } catch {
    return res.status(401).json({ message: "Invalid token" });
  }
}

export function authorize(...roles: AuthRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) return res.status(403).json({ message: "Forbidden" });
    if (roles.includes("admin") && (!isOnlyAdminEmail(req.user.email) || req.user.role !== "admin")) {
      return res.status(403).json({ message: "Admin access is restricted to the configured administrator email" });
    }
    next();
  };
}
