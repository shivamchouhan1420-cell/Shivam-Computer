import { connectDb } from "../config/db.js";
import { ensureOnlyEmailAdmin } from "../utils/admin-user.js";
import { formatDatabaseStartupError } from "../utils/database-error.js";

async function resetAdmin() {
  await connectDb();
  const result = await ensureOnlyEmailAdmin();
  console.log(JSON.stringify({
    onlyAdminEmail: result.adminEmail,
    adminUserExists: result.createdOrUpdated,
    role: result.admin?.role ?? null,
    bcryptPasswordVerified: result.passwordVerified,
    note: "Only this email is admin. All other users were demoted to user."
  }, null, 2));
  process.exit(result.createdOrUpdated && result.passwordVerified ? 0 : 1);
}

resetAdmin().catch((error) => {
  console.error(formatDatabaseStartupError(error));
  process.exit(1);
});
