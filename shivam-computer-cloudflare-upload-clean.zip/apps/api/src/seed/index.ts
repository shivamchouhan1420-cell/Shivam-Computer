import { courses, sampleProducts, brands, contactInfo } from "@scm/shared";
import { connectDb } from "../config/db.js";
import { Admission } from "../models/Admission.js";
import { Content } from "../models/Content.js";
import { Course } from "../models/Course.js";
import { Message } from "../models/Message.js";
import { Product } from "../models/Product.js";
import { User } from "../models/User.js";
import { makeAdmissionNumber, makeStudentId } from "../utils/ids.js";
import { ensureOnlyEmailAdmin } from "../utils/admin-user.js";

async function seed() {
  await connectDb();
  await Promise.all([
    Product.deleteMany({}),
    Course.deleteMany({}),
    Content.deleteMany({}),
    Message.deleteMany({}),
    Admission.deleteMany({}),
    User.deleteMany({})
  ]);

  await User.create([
    { name: "Demo User", email: "student@shivamcomputer.in", mobile: "9111111111", password: "Student@12345", role: "user", isEmailVerified: true }
  ]);

  const adminResult = await ensureOnlyEmailAdmin();
  if (!adminResult.passwordVerified) throw new Error("Admin password bcrypt verification failed after seed");

  await Product.insertMany(sampleProducts.map((product) => ({ ...product, gallery: [{ url: product.image }], isActive: true })));
  await Course.insertMany(courses.map((course) => ({
    ...course,
    practicalLabs: ["Dedicated practice time", "Trainer review", "Weekly assignment"],
    certificate: "Certificate support after successful completion",
    faqs: [
      { question: "Are practical classes included?", answer: "Yes, each course includes practical labs and projects." },
      { question: "Can I apply online?", answer: "Yes, the admission form is available online." }
    ],
    isActive: true
  })));

  await Admission.create({
    studentId: makeStudentId(),
    admissionNumber: makeAdmissionNumber(),
    aadhaar: "123456789012",
    name: "Demo Student",
    fatherName: "Demo Father",
    motherName: "Demo Mother",
    dob: "2004-01-01",
    gender: "Male",
    category: "General",
    mobile: "9111111111",
    whatsapp: "9111111111",
    email: "student@shivamcomputer.in",
    address: "Maheshwar",
    city: "Maheshwar",
    state: "Madhya Pradesh",
    pinCode: "451224",
    qualification: "12th",
    courseSelected: "dca"
  });

  await Content.insertMany([
    ...brands.map((brand) => ({ title: brand, slug: brand.toLowerCase(), type: "brand", body: `${brand} products and service support.` })),
    { title: "Makhanlal Chaturvedi National University", slug: "mcu", type: "university", body: "University affiliation guidance and course information." },
    { title: "Best Laptop for Students", slug: "best-laptop-for-students", type: "blog", body: "A practical guide to choosing student laptops." },
    { title: "Computer Lab", slug: "computer-lab", type: "gallery", image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80" },
    { title: "Great course support", slug: "great-course-support", type: "testimonial", body: "Practical classes helped me build confidence.", rating: 5 },
    { title: "Home Hero Banner", slug: "home-hero", type: "banner", image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=85" },
    { title: "Website Settings", slug: "website-settings", type: "settings", meta: { phone: contactInfo.phone, whatsapp: contactInfo.whatsapp, whatsappLink: contactInfo.whatsappLink, callLink: contactInfo.callLink, email: contactInfo.email, address1: contactInfo.address1, address2: contactInfo.address2 } }
  ]);

  console.log("Seed complete");
  process.exit(0);
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
