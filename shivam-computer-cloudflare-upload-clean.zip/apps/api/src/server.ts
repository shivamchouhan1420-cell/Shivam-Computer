import { app } from "./app.js";
import { connectDb } from "./config/db.js";
import { env } from "./config/env.js";
import { formatDatabaseStartupError } from "./utils/database-error.js";

connectDb()
  .then(() => {
    app.listen(env.port, () => console.log(`API running on http://localhost:${env.port}/api`));
  })
  .catch((error) => {
    console.error(formatDatabaseStartupError(error));
    process.exit(1);
  });
