import { env } from "../config/env.js";

export function formatDatabaseStartupError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);

  if (message.includes("ECONNREFUSED") && message.includes("27017")) {
    return [
      "MongoDB connection failed: nothing is listening at 127.0.0.1:27017.",
      "",
      "Fix one of these ways:",
      "1. Start a local MongoDB service.",
      "2. Run `docker compose up -d mongo` if Docker is installed.",
      "3. Set `MONGODB_URI` in `apps/api/.env` to a MongoDB Atlas or other remote MongoDB connection string.",
      "",
      `Current MONGODB_URI: ${env.mongoUri}`,
      "",
      "After MongoDB is reachable, run:",
      "pnpm --filter @scm/api reset-admin",
      "pnpm --filter @scm/api dev"
    ].join("\n");
  }

  return message;
}
