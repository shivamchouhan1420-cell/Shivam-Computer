import PDFDocument from "pdfkit";
import type { Response } from "express";

export function streamAdmissionReceipt(res: Response, admission: any) {
  const doc = new PDFDocument({ margin: 48 });
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="${admission.admissionNumber}.pdf"`);
  doc.pipe(res);
  doc.fontSize(20).text("Shivam Computer Maheshwar", { align: "center" });
  doc.moveDown().fontSize(12).text("Admission Receipt", { align: "center" });
  doc.moveDown();
  [
    ["Admission Number", admission.admissionNumber],
    ["Student ID", admission.studentId],
    ["Name", admission.name],
    ["Course", admission.courseSelected],
    ["Mobile", admission.mobile],
    ["Fee Status", admission.feeStatus],
    ["Status", admission.status]
  ].forEach(([label, value]) => doc.text(`${label}: ${value ?? ""}`));
  doc.moveDown().text("This is a computer generated receipt.");
  doc.end();
}
