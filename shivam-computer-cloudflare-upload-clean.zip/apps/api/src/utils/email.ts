import nodemailer from "nodemailer";
import { env } from "../config/env.js";

export async function sendMail(to: string, subject: string, text: string) {
  if (!process.env.SMTP_HOST) return { skipped: true };
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT ?? 587),
    secure: false,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
  });
  return transport.sendMail({ from: env.mailFrom, to, subject, text });
}
