export function makeStudentId() {
  return `SCM-STU-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
}

export function makeAdmissionNumber() {
  return `SCM-ADM-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
}

export function makeOrderNumber() {
  return `SCM-ORD-${Date.now().toString().slice(-7)}`;
}
