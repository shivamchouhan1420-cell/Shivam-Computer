import bcrypt from "bcryptjs";
import { adminBootstrapPassword, onlyAdminEmail } from "../config/admin.js";
import { User } from "../models/User.js";

export async function ensureOnlyEmailAdmin() {
  const passwordHash = await bcrypt.hash(adminBootstrapPassword, 12);

  // Demote every existing account first so only the configured email can retain admin powers.
  await User.updateMany({ email: { $ne: onlyAdminEmail } }, { $set: { role: "user" }, $unset: { username: "" } });

  const admin = await User.findOneAndUpdate(
    { email: onlyAdminEmail },
    {
      $set: {
        name: "Shivam Chouhan",
        email: onlyAdminEmail,
        password: passwordHash,
        role: "admin",
        isEmailVerified: true
      },
      $unset: { username: "" }
    },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  ).select("+password");

  const passwordVerified = Boolean(admin && await bcrypt.compare(adminBootstrapPassword, admin.password));
  return { admin, adminEmail: onlyAdminEmail, createdOrUpdated: Boolean(admin), passwordVerified };
}
