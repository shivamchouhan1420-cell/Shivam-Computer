import jwt from "jsonwebtoken";
import type { SignOptions } from "jsonwebtoken";
import { env } from "../config/env.js";

export function signToken(id: string) {
  const options: SignOptions = { expiresIn: env.jwtExpiresIn as SignOptions["expiresIn"] };
  return jwt.sign({ id }, env.jwtSecret, options);
}

export function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
