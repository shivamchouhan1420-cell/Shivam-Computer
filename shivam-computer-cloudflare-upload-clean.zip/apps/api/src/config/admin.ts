export const onlyAdminEmail = (process.env.ADMIN_EMAIL ?? "shivamchouhan1420@gmail.com").toLowerCase();
export const adminBootstrapPassword = process.env.ADMIN_BOOTSTRAP_PASSWORD ?? "Admin@12345";

export function isOnlyAdminEmail(email: string) {
  return email.toLowerCase() === onlyAdminEmail;
}
