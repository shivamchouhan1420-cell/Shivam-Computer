import dotenv from "dotenv";

dotenv.config();

export const env = {
  nodeEnv: process.env.NODE_ENV ?? "development",
  port: Number(process.env.PORT ?? 5001),
  mongoUri: process.env.MONGODB_URI ?? "mongodb://127.0.0.1:27017/shivam-computer-maheshwar",
  jwtSecret: process.env.JWT_SECRET ?? "dev-secret-change-me",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? "7d",
  clientUrl: process.env.CLIENT_URL ?? "http://localhost:3000",
  mailFrom: process.env.MAIL_FROM ?? "Shivam Computer <nicecomputer8513mhs@gmail.com>"
};
