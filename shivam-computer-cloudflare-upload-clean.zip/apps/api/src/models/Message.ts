import mongoose, { Schema } from "mongoose";

const messageSchema = new Schema({
  name: String,
  email: String,
  mobile: String,
  subject: String,
  message: String,
  status: { type: String, enum: ["new", "read", "closed"], default: "new" }
}, { timestamps: true });

export const Message = mongoose.model("Message", messageSchema);
