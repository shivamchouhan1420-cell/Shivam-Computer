import mongoose, { Schema } from "mongoose";

const loginHistorySchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: "User" },
  email: String,
  role: String,
  ip: String,
  userAgent: String,
  success: Boolean
}, { timestamps: true });

export const LoginHistory = mongoose.model("LoginHistory", loginHistorySchema);
