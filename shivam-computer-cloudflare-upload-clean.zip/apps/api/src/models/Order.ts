import mongoose, { Schema } from "mongoose";

const orderSchema = new Schema({
  orderNumber: { type: String, unique: true },
  user: { type: Schema.Types.ObjectId, ref: "User" },
  items: [{
    product: { type: Schema.Types.ObjectId, ref: "Product" },
    name: String,
    sku: String,
    quantity: Number,
    price: Number
  }],
  couponCode: String,
  subtotal: Number,
  discount: Number,
  total: Number,
  paymentStatus: { type: String, enum: ["pending", "paid", "failed", "refunded"], default: "pending" },
  orderStatus: { type: String, enum: ["placed", "processing", "shipped", "delivered", "cancelled"], default: "placed" },
  tracking: [{ status: String, note: String, at: Date }],
  shippingAddress: Schema.Types.Mixed
}, { timestamps: true });

export const Order = mongoose.model("Order", orderSchema);
