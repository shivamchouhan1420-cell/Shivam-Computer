import mongoose, { Schema } from "mongoose";

const admissionSchema = new Schema({
  studentId: { type: String, unique: true },
  admissionNumber: { type: String, unique: true },
  photo: String,
  signature: String,
  aadhaar: { type: String, required: true },
  name: { type: String, required: true },
  fatherName: String,
  motherName: String,
  dob: String,
  gender: String,
  category: String,
  mobile: String,
  whatsapp: String,
  email: String,
  address: String,
  city: String,
  state: String,
  pinCode: String,
  qualification: String,
  courseSelected: String,
  status: { type: String, enum: ["submitted", "approved", "rejected"], default: "submitted" },
  feeStatus: { type: String, enum: ["pending", "partial", "paid"], default: "pending" },
  paymentHistory: [{ amount: Number, mode: String, paidAt: Date, receiptNumber: String }]
}, { timestamps: true });

export const Admission = mongoose.model("Admission", admissionSchema);
