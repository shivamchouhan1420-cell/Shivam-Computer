import mongoose, { Schema } from "mongoose";

const productSchema = new Schema({
  name: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  category: { type: String, required: true },
  brand: { type: String, required: true },
  sku: { type: String, required: true, unique: true },
  gallery: [{ url: String, publicId: String }],
  image: String,
  price: { type: Number, required: true },
  mrp: Number,
  discount: Number,
  offer: String,
  stock: { type: Number, default: 0 },
  description: String,
  specifications: Schema.Types.Mixed,
  rating: { type: Number, default: 0 },
  reviewCount: { type: Number, default: 0 },
  recentlyViewedScore: { type: Number, default: 0 },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

productSchema.index({ name: "text", category: "text", brand: "text", description: "text" });

export const Product = mongoose.model("Product", productSchema);
