import mongoose, { Schema } from "mongoose";

const courseSchema = new Schema({
  title: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  overview: String,
  eligibility: String,
  duration: String,
  fees: Number,
  syllabus: [String],
  projects: [String],
  practicalLabs: [String],
  certificate: String,
  careerScope: [String],
  faqs: [{ question: String, answer: String }],
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export const Course = mongoose.model("Course", courseSchema);
