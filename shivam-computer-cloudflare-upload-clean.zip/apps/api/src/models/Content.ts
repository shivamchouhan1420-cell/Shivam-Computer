import mongoose, { Schema } from "mongoose";

const simpleContentSchema = new Schema({
  title: { type: String, required: true },
  slug: { type: String, index: true },
  type: { type: String, required: true },
  image: String,
  body: String,
  rating: Number,
  meta: Schema.Types.Mixed,
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export const Content = mongoose.model("Content", simpleContentSchema);
