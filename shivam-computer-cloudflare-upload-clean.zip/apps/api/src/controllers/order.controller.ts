import type { Request, Response } from "express";
import { Order } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { makeOrderNumber } from "../utils/ids.js";
import { streamExcel } from "../utils/excel.js";

export async function createOrder(req: Request, res: Response) {
  const items = await Promise.all((req.body.items ?? []).map(async (line: any) => {
    const product = await Product.findById(line.productId);
    if (!product || product.stock < line.quantity) throw new Error(`Stock unavailable for ${line.productId}`);
    product.stock -= line.quantity;
    await product.save();
    return { product: product._id, name: product.name, sku: product.sku, quantity: line.quantity, price: product.price };
  }));
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = req.body.couponCode === "SCM500" ? 500 : 0;
  const order = await Order.create({ orderNumber: makeOrderNumber(), user: req.user?.id, items, subtotal, discount, total: subtotal - discount, couponCode: req.body.couponCode, shippingAddress: req.body.shippingAddress, tracking: [{ status: "placed", note: "Order placed", at: new Date() }] });
  res.status(201).json(order);
}

export async function exportOrders(_req: Request, res: Response) {
  const rows = await Order.find().lean();
  await streamExcel(res, "orders", rows.map((row: any) => ({ orderNumber: row.orderNumber, total: row.total, paymentStatus: row.paymentStatus, orderStatus: row.orderStatus })));
}
