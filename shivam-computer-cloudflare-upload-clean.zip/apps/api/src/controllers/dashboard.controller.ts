import type { Request, Response } from "express";
import { Admission } from "../models/Admission.js";
import { Content } from "../models/Content.js";
import { Course } from "../models/Course.js";
import { Message } from "../models/Message.js";
import { Order } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { User } from "../models/User.js";

export async function analytics(_req: Request, res: Response) {
  const [users, products, courses, admissions, orders, messages, blogs] = await Promise.all([
    User.countDocuments(),
    Product.countDocuments(),
    Course.countDocuments(),
    Admission.countDocuments(),
    Order.countDocuments(),
    Message.countDocuments(),
    Content.countDocuments({ type: "blog" })
  ]);
  const revenue = await Order.aggregate([{ $group: { _id: null, total: { $sum: "$total" } } }]);
  res.json({ users, products, courses, admissions, orders, messages, blogs, revenue: revenue[0]?.total ?? 0 });
}
