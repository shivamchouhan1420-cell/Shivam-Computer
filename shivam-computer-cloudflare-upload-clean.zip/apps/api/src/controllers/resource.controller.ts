import type { Model } from "mongoose";
import type { Request, Response } from "express";

export function crudController(model: Model<any>) {
  return {
    list: async (req: Request, res: Response) => {
      const query = buildQuery(req.query);
      const page = Math.max(Number(req.query.page ?? 1), 1);
      const limit = Math.min(Math.max(Number(req.query.limit ?? 20), 1), 100);
      const [items, total] = await Promise.all([
        model.find(query).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
        model.countDocuments(query)
      ]);
      res.json({ items, total, page, pages: Math.ceil(total / limit) });
    },
    get: async (req: Request, res: Response) => {
      const item = await model.findOne({ $or: [{ _id: req.params.idOrSlug }, { slug: req.params.idOrSlug }] }).catch(() => null);
      if (!item) return res.status(404).json({ message: "Record not found" });
      res.json(item);
    },
    create: async (req: Request, res: Response) => {
      const item = await model.create(req.body);
      res.status(201).json(item);
    },
    update: async (req: Request, res: Response) => {
      const item = await model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
      if (!item) return res.status(404).json({ message: "Record not found" });
      res.json(item);
    },
    remove: async (req: Request, res: Response) => {
      const item = await model.findByIdAndDelete(req.params.id);
      if (!item) return res.status(404).json({ message: "Record not found" });
      res.json({ message: "Deleted" });
    }
  };
}

function buildQuery(query: Request["query"]) {
  const filters: Record<string, unknown> = {};
  ["category", "brand", "type", "status", "role", "courseSelected"].forEach((key) => {
    if (query[key]) filters[key] = query[key];
  });
  if (query.search) filters.$text = { $search: String(query.search) };
  if (query.minPrice || query.maxPrice) filters.price = { ...(query.minPrice ? { $gte: Number(query.minPrice) } : {}), ...(query.maxPrice ? { $lte: Number(query.maxPrice) } : {}) };
  if (query.rating) filters.rating = { $gte: Number(query.rating) };
  return filters;
}
