import type { Request, Response } from "express";
import { z } from "zod";
import { Admission } from "../models/Admission.js";
import { makeAdmissionNumber, makeStudentId } from "../utils/ids.js";
import { streamExcel } from "../utils/excel.js";
import { streamAdmissionReceipt } from "../utils/pdf.js";
import { sendMail } from "../utils/email.js";

const admissionSchema = z.object({
  aadhaar: z.string().min(12),
  name: z.string().min(2),
  fatherName: z.string().optional(),
  motherName: z.string().optional(),
  dob: z.string().optional(),
  gender: z.string().optional(),
  category: z.string().optional(),
  mobile: z.string().optional(),
  whatsapp: z.string().optional(),
  email: z.string().email(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  pinCode: z.string().optional(),
  qualification: z.string().optional(),
  courseSelected: z.string().min(1)
});

export async function createAdmission(req: Request, res: Response) {
  const payload = admissionSchema.parse(req.body);
  const admission = await Admission.create({
    ...payload,
    studentId: makeStudentId(),
    admissionNumber: makeAdmissionNumber()
  });
  await sendMail(admission.email!, "Admission submitted", `Your admission number is ${admission.admissionNumber}`);
  res.status(201).json(admission);
}

export async function exportAdmissions(req: Request, res: Response) {
  const rows = await Admission.find().lean();
  await streamExcel(res, "admissions", rows.map((row: any) => ({
    admissionNumber: row.admissionNumber,
    studentId: row.studentId,
    name: row.name,
    mobile: row.mobile,
    email: row.email,
    courseSelected: row.courseSelected,
    status: row.status,
    feeStatus: row.feeStatus
  })));
}

export async function admissionReceipt(req: Request, res: Response) {
  const admission = await Admission.findById(req.params.id);
  if (!admission) return res.status(404).json({ message: "Admission not found" });
  streamAdmissionReceipt(res, admission);
}
