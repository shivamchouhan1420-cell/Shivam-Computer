import type { Request, Response } from "express";
import { cloudinary } from "../config/cloudinary.js";

export async function uploadFile(req: Request, res: Response) {
  if (!req.file) return res.status(400).json({ message: "File required" });
  if (!process.env.CLOUDINARY_CLOUD_NAME) return res.status(501).json({ message: "Cloudinary is not configured" });
  const result = await new Promise<any>((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream({ folder: "shivam-computer" }, (error, uploadResult) => error ? reject(error) : resolve(uploadResult));
    stream.end(req.file!.buffer);
  });
  res.status(201).json({ url: result.secure_url, publicId: result.public_id });
}
