import type { Request, Response } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { isOnlyAdminEmail } from "../config/admin.js";
import { LoginHistory } from "../models/LoginHistory.js";
import { User } from "../models/User.js";
import { generateOtp, signToken } from "../utils/tokens.js";
import { sendMail } from "../utils/email.js";

const registerSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  mobile: z.string().optional(),
  password: z.string().min(8)
});

export async function register(req: Request, res: Response) {
  const payload = registerSchema.parse(req.body);
  const user = await User.create({ ...payload, role: "user" });
  const token = signToken(String(user._id));
  res.status(201).json({ token, user: publicUser(user) });
}

export async function login(req: Request, res: Response) {
  const { email, password } = z.object({ email: z.string().email(), password: z.string() }).parse(req.body);
  const user = await User.findOne({ email }).select("+password");
  const success = Boolean(user && await bcrypt.compare(password, user.password));
  await LoginHistory.create({ user: user?._id, email, role: user?.role, ip: req.ip, userAgent: req.headers["user-agent"], success });
  if (!success || !user) return res.status(401).json({ message: "Invalid email or password" });
  user.lastLoginAt = new Date();
  await user.save();
  res.json({ token: signToken(String(user._id)), user: publicUser(user) });
}

export async function adminLogin(req: Request, res: Response) {
  const { email, password } = z.object({
    email: z.string().email(),
    password: z.string().min(8)
  }).parse(req.body);

  if (!isOnlyAdminEmail(email)) return res.status(403).json({ message: "Access denied" });
  const user = await User.findOne({ email: email.toLowerCase(), role: "admin" }).select("+password");
  const success = Boolean(user && await bcrypt.compare(password, user.password));
  await LoginHistory.create({ user: user?._id, email, role: user?.role, ip: req.ip, userAgent: req.headers["user-agent"], success });
  if (!success || !user) return res.status(401).json({ message: "Invalid admin credentials" });
  user.lastLoginAt = new Date();
  await user.save();
  res.json({ token: signToken(String(user._id)), user: publicUser(user) });
}

export async function me(req: Request, res: Response) {
  const user = await User.findById(req.user!.id);
  res.json({ user: publicUser(user) });
}

export async function forgotPassword(req: Request, res: Response) {
  const { email } = z.object({ email: z.string().email() }).parse(req.body);
  const user = await User.findOne({ email });
  if (user) {
    const otp = generateOtp();
    user.otpHash = await bcrypt.hash(otp, 10);
    user.otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);
    await user.save();
    await sendMail(email, "Password reset OTP", `Your Shivam Computer OTP is ${otp}`);
  }
  res.json({ message: "If the email exists, an OTP has been sent" });
}

export async function resetPassword(req: Request, res: Response) {
  const { email, otp, password } = z.object({ email: z.string().email(), otp: z.string(), password: z.string().min(8) }).parse(req.body);
  const user = await User.findOne({ email }).select("+password");
  if (!user?.otpHash || !user.otpExpiresAt || user.otpExpiresAt < new Date()) return res.status(400).json({ message: "OTP expired" });
  const valid = await bcrypt.compare(otp, user.otpHash);
  if (!valid) return res.status(400).json({ message: "Invalid OTP" });
  user.password = password;
  user.otpHash = undefined;
  user.otpExpiresAt = undefined;
  await user.save();
  res.json({ message: "Password reset successful" });
}

function publicUser(user: any) {
  if (!user) return null;
  const role = user.role === "admin" && isOnlyAdminEmail(user.email) ? "admin" : "user";
  return { id: user._id, name: user.name, email: user.email, mobile: user.mobile, role, isEmailVerified: user.isEmailVerified };
}
