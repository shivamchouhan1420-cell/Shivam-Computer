"use client";

import { LogOut } from "lucide-react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

export function AdminLogoutButton() {
  const router = useRouter();

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    toast.success("Logged out");
    router.replace("/admin/login");
    router.refresh();
  }

  return (
    <button onClick={logout} className="inline-flex items-center justify-center gap-2 rounded-md border border-slate-200 px-4 py-2 text-sm font-bold dark:border-slate-800">
      <LogOut className="h-4 w-4" />
      Logout
    </button>
  );
}
