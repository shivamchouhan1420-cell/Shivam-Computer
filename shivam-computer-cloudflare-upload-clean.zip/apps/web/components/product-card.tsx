import { Heart, ShoppingCart, Star } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

type Product = {
  slug: string;
  name: string;
  category: string;
  brand: string;
  price: number;
  mrp: number;
  discount: number;
  rating: number;
  stock: number;
  image: string;
};

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group rounded-lg border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-premium dark:border-slate-800 dark:bg-slate-900">
      <Link href={`/products/${product.slug}`} className="block">
        <div className="relative aspect-[4/3] overflow-hidden rounded-t-lg bg-slate-100">
          <Image src={product.image} alt={product.name} fill sizes="(max-width: 768px) 100vw, 25vw" className="object-cover transition duration-500 group-hover:scale-105" />
          <span className="absolute left-3 top-3 rounded-md bg-leaf px-2 py-1 text-xs font-bold text-white">{product.discount}% off</span>
        </div>
      </Link>
      <div className="p-4">
        <div className="flex items-center justify-between gap-3 text-xs font-semibold text-slate-500">
          <span>{product.brand}</span>
          <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-saffron text-saffron" /> {product.rating.toFixed(1)}</span>
        </div>
        <Link href={`/products/${product.slug}`} className="mt-2 line-clamp-2 block min-h-12 font-bold text-ink hover:text-river dark:text-white">{product.name}</Link>
        <div className="mt-3 flex items-end gap-2">
          <span className="text-xl font-black">₹{product.price.toLocaleString("en-IN")}</span>
          <span className="text-sm text-slate-400 line-through">₹{product.mrp.toLocaleString("en-IN")}</span>
        </div>
        <div className="mt-4 grid grid-cols-[1fr_auto] gap-2">
          <button className="focus-ring inline-flex items-center justify-center gap-2 rounded-md bg-ink px-3 py-2 text-sm font-semibold text-white dark:bg-white dark:text-ink"><ShoppingCart className="h-4 w-4" /> Add</button>
          <button aria-label="Wishlist" className="focus-ring grid h-10 w-10 place-items-center rounded-md border border-slate-200 dark:border-slate-800"><Heart className="h-4 w-4" /></button>
        </div>
      </div>
    </article>
  );
}
