import { contactInfo } from "@scm/shared";
import { MessageCircle } from "lucide-react";

export function FloatingWhatsApp() {
  return (
    <a
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-50 grid h-12 w-12 place-items-center rounded-full bg-leaf text-white shadow-premium transition hover:-translate-y-0.5"
      href={contactInfo.whatsappLink}
      rel="noreferrer"
      target="_blank"
      title="Chat on WhatsApp"
    >
      <MessageCircle className="h-6 w-6" />
    </a>
  );
}
