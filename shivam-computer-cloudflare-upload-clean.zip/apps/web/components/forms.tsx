"use client";

import { courses } from "@scm/shared";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import { apiFetch } from "@/lib/api";

const admissionSchema = z.object({
  name: z.string().min(2),
  fatherName: z.string().min(2),
  motherName: z.string().min(2),
  dob: z.string().min(1),
  gender: z.string().min(1),
  category: z.string().min(1),
  mobile: z.string().min(10),
  whatsapp: z.string().min(10),
  email: z.string().email(),
  aadhaar: z.string().min(12),
  address: z.string().min(5),
  city: z.string().min(2),
  state: z.string().min(2),
  pinCode: z.string().min(6),
  qualification: z.string().min(2),
  courseSelected: z.string().min(1)
});

type AdmissionFormValues = z.infer<typeof admissionSchema>;

export function AdmissionForm({ selectedCourse }: { selectedCourse?: string }) {
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<AdmissionFormValues>({
    resolver: zodResolver(admissionSchema),
    defaultValues: { courseSelected: selectedCourse ?? "dca" }
  });

  async function onSubmit(values: AdmissionFormValues) {
    try {
      const result = await apiFetch<{ admissionNumber: string; studentId: string }>("/admissions", {
        method: "POST",
        body: JSON.stringify(values)
      });
      toast.success(`Admission submitted: ${result.admissionNumber}`);
      reset();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Admission failed");
    }
  }

  const fields = [
    ["name", "Name"], ["fatherName", "Father Name"], ["motherName", "Mother Name"], ["dob", "DOB"], ["gender", "Gender"], ["category", "Category"],
    ["mobile", "Mobile"], ["whatsapp", "WhatsApp"], ["email", "Email"], ["aadhaar", "Aadhaar"], ["address", "Address"], ["city", "City"],
    ["state", "State"], ["pinCode", "PIN Code"], ["qualification", "Qualification"]
  ] as const;

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="grid gap-4 rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 md:grid-cols-2">
      <label className="grid gap-1 text-sm font-semibold">
        Photo
        <input type="file" accept="image/*" className="rounded-md border border-slate-200 p-2 dark:border-slate-800" />
      </label>
      <label className="grid gap-1 text-sm font-semibold">
        Signature
        <input type="file" accept="image/*" className="rounded-md border border-slate-200 p-2 dark:border-slate-800" />
      </label>
      {fields.map(([name, label]) => (
        <label key={name} className={`grid gap-1 text-sm font-semibold ${name === "address" ? "md:col-span-2" : ""}`}>
          {label}
          <input type={name === "dob" ? "date" : "text"} {...register(name)} className="rounded-md border border-slate-200 bg-transparent px-3 py-3 outline-none focus:border-river dark:border-slate-800" />
          {errors[name] ? <span className="text-xs text-red-600">{errors[name]?.message}</span> : null}
        </label>
      ))}
      <label className="grid gap-1 text-sm font-semibold md:col-span-2">
        Course Selected
        <select {...register("courseSelected")} className="rounded-md border border-slate-200 bg-transparent px-3 py-3 outline-none focus:border-river dark:border-slate-800">
          {courses.map((course) => <option key={course.slug} value={course.slug}>{course.title}</option>)}
        </select>
      </label>
      <button disabled={isSubmitting} className="rounded-md bg-ink px-5 py-3 font-bold text-white disabled:opacity-60 dark:bg-white dark:text-ink md:col-span-2">
        {isSubmitting ? "Submitting..." : "Submit Admission"}
      </button>
    </form>
  );
}
