import Link from "next/link";
import type { ComponentProps } from "react";

export function ButtonLink({ className = "", ...props }: ComponentProps<typeof Link>) {
  return (
    <Link
      className={`focus-ring inline-flex min-h-11 items-center justify-center rounded-md bg-ink px-5 py-3 text-sm font-semibold text-white shadow-premium transition hover:-translate-y-0.5 hover:bg-slate-700 dark:bg-white dark:text-ink ${className}`}
      {...props}
    />
  );
}

export function Section({ title, eyebrow, children }: { title: string; eyebrow?: string; children: React.ReactNode }) {
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
      <div className="mb-8 max-w-3xl">
        {eyebrow ? <p className="text-sm font-bold uppercase tracking-wider text-river">{eyebrow}</p> : null}
        <h2 className="mt-2 text-3xl font-bold text-ink dark:text-white sm:text-4xl">{title}</h2>
      </div>
      {children}
    </section>
  );
}

export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 ${className}`}>{children}</div>;
}
