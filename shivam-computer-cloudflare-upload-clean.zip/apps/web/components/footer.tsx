import { brands, contactInfo, courses, productCategories } from "@scm/shared";
import { Facebook, Instagram, Mail, MapPin, Phone, Youtube } from "lucide-react";
import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-2 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="text-xl font-black">Shivam Computer Maheshwar</div>
          <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Your Trusted Computer Store & Computer Training Institute. Affiliated training guidance with Makhanlal Chaturvedi National University courses.</p>
          <div className="mt-4 flex gap-2">
            {[Facebook, Instagram, Youtube, Mail].map((Icon, index) => <span key={index} className="grid h-9 w-9 place-items-center rounded-md bg-slate-100 dark:bg-slate-900"><Icon className="h-4 w-4" /></span>)}
          </div>
        </div>
        <FooterColumn title="Products" items={productCategories.slice(0, 10).map((label) => ({ label, href: `/categories/${label.toLowerCase().replaceAll(" ", "-")}` }))} />
        <FooterColumn title="Courses" items={courses.slice(0, 10).map((course) => ({ label: course.title, href: `/courses/${course.slug}` }))} />
        <div>
          <h3 className="font-bold">Contact</h3>
          <div className="mt-4 space-y-3 text-sm text-slate-600 dark:text-slate-300">
            <p className="flex gap-2"><MapPin className="h-4 w-4 shrink-0" /> {contactInfo.address1}</p>
            <p className="flex gap-2"><MapPin className="h-4 w-4 shrink-0" /> {contactInfo.address2}</p>
            <p className="flex gap-2"><Phone className="h-4 w-4 shrink-0" /> <a href={contactInfo.callLink}>{contactInfo.phone}</a></p>
            <p className="flex gap-2"><Mail className="h-4 w-4 shrink-0" /> <a href={`mailto:${contactInfo.email}`}>{contactInfo.email}</a></p>
          </div>
          <form className="mt-5 flex rounded-md border border-slate-200 p-1 dark:border-slate-800">
            <input aria-label="Email" className="min-w-0 flex-1 bg-transparent px-3 text-sm outline-none" placeholder="Newsletter email" />
            <button className="rounded-md bg-ink px-3 py-2 text-sm font-semibold text-white dark:bg-white dark:text-ink">Join</button>
          </form>
        </div>
      </div>
      <div className="border-t border-slate-200 px-4 py-5 text-center text-sm text-slate-500 dark:border-slate-800">
        Copyright 2026 Shivam Computer Maheshwar. <Link href="/privacy-policy">Privacy</Link> | <Link href="/terms-and-conditions">Terms</Link> | <Link href="/refund-policy">Refund</Link>
      </div>
    </footer>
  );
}

function FooterColumn({ title, items }: { title: string; items: { label: string; href: string }[] }) {
  return (
    <div>
      <h3 className="font-bold">{title}</h3>
      <div className="mt-4 grid gap-2 text-sm">
        {items.map((item) => <Link key={item.href} className="text-slate-600 hover:text-river dark:text-slate-300" href={item.href}>{item.label}</Link>)}
      </div>
    </div>
  );
}
