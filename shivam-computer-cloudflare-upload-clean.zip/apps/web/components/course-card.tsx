import { Award, Clock, GraduationCap } from "lucide-react";
import Link from "next/link";

type Course = {
  slug: string;
  title: string;
  duration: string;
  fees: number;
  overview: string;
};

export function CourseCard({ course }: { course: Course }) {
  return (
    <article className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-premium dark:border-slate-800 dark:bg-slate-900">
      <div className="grid h-12 w-12 place-items-center rounded-lg bg-river/10 text-river"><GraduationCap className="h-6 w-6" /></div>
      <h3 className="mt-4 text-xl font-black">{course.title}</h3>
      <p className="mt-2 line-clamp-3 text-sm leading-6 text-slate-600 dark:text-slate-300">{course.overview}</p>
      <div className="mt-4 grid gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
        <span className="flex items-center gap-2"><Clock className="h-4 w-4 text-saffron" /> {course.duration}</span>
        <span className="flex items-center gap-2"><Award className="h-4 w-4 text-leaf" /> ₹{course.fees.toLocaleString("en-IN")} total fees</span>
      </div>
      <div className="mt-5 grid grid-cols-2 gap-2">
        <Link href={`/courses/${course.slug}`} className="rounded-md border border-slate-200 px-3 py-2 text-center text-sm font-bold dark:border-slate-800">Details</Link>
        <Link href={`/admission?course=${course.slug}`} className="rounded-md bg-river px-3 py-2 text-center text-sm font-bold text-white">Admission</Link>
      </div>
    </article>
  );
}
