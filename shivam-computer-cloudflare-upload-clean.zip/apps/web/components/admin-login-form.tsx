"use client";

import { LockKeyhole, LogIn, UserRound } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";

export function AdminLoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.message ?? "Invalid admin credentials");
      toast.success("Admin login successful");
      router.replace(searchParams.get("next") ?? "/admin");
      router.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to login");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="mx-auto grid max-w-md gap-4 rounded-lg border border-slate-200 bg-white p-6 shadow-premium dark:border-slate-800 dark:bg-slate-900">
      <div className="grid h-12 w-12 place-items-center rounded-lg bg-river/10 text-river">
        <LockKeyhole className="h-6 w-6" />
      </div>
      <label className="grid gap-2 text-sm font-bold">
        Admin Email
        <span className="flex items-center gap-2 rounded-md border border-slate-200 px-3 py-3 dark:border-slate-800">
          <UserRound className="h-4 w-4 text-slate-500" />
          <input value={email} onChange={(event) => setEmail(event.target.value)} className="min-w-0 flex-1 bg-transparent outline-none" type="email" autoComplete="email" required />
        </span>
      </label>
      <label className="grid gap-2 text-sm font-bold">
        Admin Password
        <span className="flex items-center gap-2 rounded-md border border-slate-200 px-3 py-3 dark:border-slate-800">
          <LockKeyhole className="h-4 w-4 text-slate-500" />
          <input value={password} onChange={(event) => setPassword(event.target.value)} className="min-w-0 flex-1 bg-transparent outline-none" type="password" autoComplete="current-password" required />
        </span>
      </label>
      <button disabled={loading} className="inline-flex items-center justify-center gap-2 rounded-md bg-ink px-4 py-3 font-bold text-white disabled:opacity-60 dark:bg-white dark:text-ink">
        <LogIn className="h-4 w-4" />
        {loading ? "Checking..." : "Login"}
      </button>
    </form>
  );
}
