"use client";

import { navLinks } from "@scm/shared";
import { Heart, Menu, Moon, Search, ShoppingCart, Sun, UserRound, X } from "lucide-react";
import Link from "next/link";
import { useTheme } from "next-themes";
import { useState } from "react";

export function Header() {
  const [open, setOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/90">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-lg bg-ink text-lg font-black text-white dark:bg-white dark:text-ink">SC</span>
          <span className="min-w-max">
            <span className="block text-base font-black leading-tight text-ink dark:text-white">Shivam Computer</span>
            <span className="block text-xs font-semibold text-slate-500">Maheshwar</span>
          </span>
        </Link>
        <label className="hidden min-w-0 flex-1 items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 lg:flex dark:border-slate-800 dark:bg-slate-900">
          <Search className="h-4 w-4 text-slate-500" />
          <input className="w-full bg-transparent text-sm outline-none" placeholder="Search products, courses, brands..." />
        </label>
        <nav className="hidden items-center gap-1 xl:flex">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} className="rounded-md px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-900">
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-1">
          <IconButton label="Wishlist"><Heart className="h-5 w-5" /></IconButton>
          <Link aria-label="Cart" href="/cart" className="focus-ring grid h-10 w-10 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-900"><ShoppingCart className="h-5 w-5" /></Link>
          <Link aria-label="Profile" href="/student-dashboard" className="focus-ring grid h-10 w-10 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-900"><UserRound className="h-5 w-5" /></Link>
          <button aria-label="Toggle dark mode" className="focus-ring grid h-10 w-10 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-900" onClick={() => setTheme(isDark ? "light" : "dark")}>
            {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
          <button aria-label="Menu" className="focus-ring grid h-10 w-10 place-items-center rounded-md xl:hidden" onClick={() => setOpen((value) => !value)}>
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open ? (
        <div className="border-t border-slate-200 px-4 py-4 xl:hidden dark:border-slate-800">
          <div className="grid gap-2">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} onClick={() => setOpen(false)} className="rounded-md px-3 py-3 text-sm font-semibold hover:bg-slate-100 dark:hover:bg-slate-900">
                {link.label}
              </Link>
            ))}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <Link className="rounded-md border border-slate-200 px-3 py-3 text-center text-sm font-semibold dark:border-slate-800" href="/login">Login</Link>
              <Link className="rounded-md bg-river px-3 py-3 text-center text-sm font-semibold text-white" href="/register">Register</Link>
            </div>
          </div>
        </div>
      ) : null}
    </header>
  );
}

function IconButton({ label, children }: { label: string; children: React.ReactNode }) {
  return <button aria-label={label} title={label} className="focus-ring grid h-10 w-10 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-900">{children}</button>;
}
