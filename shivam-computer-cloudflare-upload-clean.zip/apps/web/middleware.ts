import { NextRequest, NextResponse } from "next/server";
import { adminCookieName } from "@/lib/admin-constants";

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (pathname === "/admin/login") return NextResponse.next();

  // Fast edge guard: unauthenticated visitors never reach admin pages.
  // Role verification still happens server-side on the admin page and in the API middleware.
  if (pathname.startsWith("/admin") && !request.cookies.get(adminCookieName)?.value) {
    const loginUrl = new URL("/admin/login", request.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"]
};
