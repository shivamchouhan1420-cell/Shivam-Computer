import { NextRequest, NextResponse } from "next/server";
import { apiBase } from "@/lib/api";
import { adminCookieName } from "@/lib/admin-constants";

export async function POST(request: NextRequest) {
  const body = await request.json();

  // The browser sends credentials only to this same-origin route.
  // This route forwards them to the backend and stores only the JWT in an HttpOnly cookie.
  const response = await fetch(`${apiBase}/auth/admin/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store"
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    return NextResponse.json({ message: data.message ?? "Invalid admin credentials" }, { status: response.status });
  }

  const nextResponse = NextResponse.json({ user: data.user });
  nextResponse.cookies.set(adminCookieName, data.token, {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 8
  });
  return nextResponse;
}
