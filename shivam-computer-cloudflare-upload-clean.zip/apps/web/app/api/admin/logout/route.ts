import { NextResponse } from "next/server";
import { adminCookieName } from "@/lib/admin-constants";

export async function POST() {
  const response = NextResponse.json({ message: "Logged out" });
  response.cookies.set(adminCookieName, "", {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0
  });
  return response;
}
