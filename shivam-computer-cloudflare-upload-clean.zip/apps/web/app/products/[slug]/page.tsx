import { sampleProducts } from "@scm/shared";
import { Heart, Minus, Plus, ShoppingCart, Star, Truck } from "lucide-react";
import Image from "next/image";
import { notFound } from "next/navigation";
import { ProductCard } from "@/components/product-card";
import { ButtonLink, Section } from "@/components/ui";

export function generateStaticParams() {
  return sampleProducts.map((product) => ({ slug: product.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = sampleProducts.find((item) => item.slug === slug);
  return { title: product?.name ?? "Product" };
}

export default async function ProductDetailsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = sampleProducts.find((item) => item.slug === slug);
  if (!product) notFound();
  return (
    <Section title={product.name} eyebrow={`${product.category} / ${product.brand}`}>
      <div className="grid gap-8 lg:grid-cols-[0.95fr_1fr]">
        <div>
          <div className="relative aspect-square overflow-hidden rounded-lg bg-slate-100 shadow-premium">
            <Image src={product.image} alt={product.name} fill priority className="object-cover" />
          </div>
          <div className="mt-3 grid grid-cols-4 gap-3">{[0, 1, 2, 3].map((item) => <div key={item} className="relative aspect-square overflow-hidden rounded-lg border border-slate-200 dark:border-slate-800"><Image src={product.image} alt={`${product.name} gallery ${item + 1}`} fill className="object-cover" /></div>)}</div>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center gap-3">
            <span className="rounded-md bg-leaf px-2 py-1 text-xs font-bold text-white">In stock: {product.stock}</span>
            <span className="flex items-center gap-1 text-sm font-bold"><Star className="h-4 w-4 fill-saffron text-saffron" /> {product.rating.toFixed(1)} rating</span>
          </div>
          <div className="mt-5 flex items-end gap-3">
            <span className="text-4xl font-black">₹{product.price.toLocaleString("en-IN")}</span>
            <span className="text-lg text-slate-400 line-through">₹{product.mrp.toLocaleString("en-IN")}</span>
            <span className="font-bold text-leaf">{product.discount}% off</span>
          </div>
          <p className="mt-4 leading-7 text-slate-600 dark:text-slate-300">{product.description}</p>
          <div className="mt-5 rounded-lg bg-slate-50 p-4 dark:bg-slate-950">
            <h2 className="font-black">Specifications</h2>
            <dl className="mt-3 grid gap-2 text-sm">
              {Object.entries(product.specifications).map(([key, value]) => <div key={key} className="flex justify-between gap-3"><dt className="capitalize text-slate-500">{key}</dt><dd className="font-semibold">{value}</dd></div>)}
              <div className="flex justify-between gap-3"><dt className="text-slate-500">SKU</dt><dd className="font-semibold">{product.sku}</dd></div>
            </dl>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <button className="inline-flex items-center gap-2 rounded-md bg-ink px-5 py-3 font-bold text-white dark:bg-white dark:text-ink"><ShoppingCart className="h-5 w-5" /> Add to Cart</button>
            <ButtonLink href="/checkout" className="bg-river dark:bg-river dark:text-white">Buy Now</ButtonLink>
            <button aria-label="Wishlist" className="grid h-12 w-12 place-items-center rounded-md border border-slate-200 dark:border-slate-800"><Heart className="h-5 w-5" /></button>
          </div>
          <div className="mt-6 flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300"><Truck className="h-4 w-4" /> Local delivery, installation guidance and invoice available.</div>
        </div>
      </div>
      <div className="mt-12">
        <h2 className="text-2xl font-black">Related Products</h2>
        <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{sampleProducts.filter((item) => item.slug !== product.slug).slice(0, 4).map((item) => <ProductCard key={item.slug} product={item} />)}</div>
      </div>
    </Section>
  );
}
