import { Star } from "lucide-react";
import { Card, Section } from "@/components/ui";

export const metadata = { title: "Testimonials" };

export default function TestimonialsPage() {
  return (
    <Section title="Testimonials" eyebrow="Customer and student success">
      <div className="grid gap-5 md:grid-cols-3">{["Laptop service and setup was excellent.", "I completed Tally with GST and got practical billing confidence.", "Best place for computer course admission guidance."].map((quote) => <Card key={quote}><div className="flex gap-1">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-saffron text-saffron" />)}</div><p className="mt-4 text-sm leading-6">{quote}</p></Card>)}</div>
    </Section>
  );
}
