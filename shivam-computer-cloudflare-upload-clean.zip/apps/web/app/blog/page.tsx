import Link from "next/link";
import { Section } from "@/components/ui";

export const metadata = { title: "Blog" };

const posts = [
  ["best-laptop-for-students", "How to choose the best laptop for students"],
  ["dca-vs-pgdca", "DCA vs PGDCA: which course is right for you"],
  ["tally-gst-career", "Career scope after Tally Prime with GST"]
];

export default function BlogPage() {
  return (
    <Section title="Latest Blog" eyebrow="Buying and career guidance">
      <div className="grid gap-5 md:grid-cols-3">{posts.map(([slug, title]) => <Link key={slug} href={`/blog/${slug}`} className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm hover:border-river dark:border-slate-800 dark:bg-slate-900"><h2 className="font-black">{title}</h2><p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">SEO-ready blog content can be managed from the admin dashboard with images, slugs, tags, meta title and Open Graph data.</p></Link>)}</div>
    </Section>
  );
}
