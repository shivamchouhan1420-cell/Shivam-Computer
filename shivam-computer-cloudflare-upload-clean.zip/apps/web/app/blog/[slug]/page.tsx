import { Section } from "@/components/ui";

export default async function BlogDetailsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const title = slug.split("-").map((word) => word[0].toUpperCase() + word.slice(1)).join(" ");
  return (
    <Section title={title} eyebrow="Blog">
      <article className="prose max-w-none rounded-lg border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 dark:prose-invert">
        <p>Practical guidance from Shivam Computer Maheshwar for students, families and businesses. This article is editable through the blog API and admin dashboard.</p>
        <h2>Key Points</h2>
        <ul><li>Clear buying or course selection checklist.</li><li>Local service and career guidance context.</li><li>SEO-friendly metadata and Open Graph support.</li></ul>
      </article>
    </Section>
  );
}
