import { Section } from "@/components/ui";

export const metadata = { title: "Privacy Policy" };

export default function PrivacyPolicyPage() {
  return <Policy title="Privacy Policy" body="We collect customer, order, admission and student data only to provide shopping, training, support, communication, invoices and certificates. Data is protected through authentication, role based access, validation and secure deployment practices." />;
}

function Policy({ title, body }: { title: string; body: string }) {
  return <Section title={title} eyebrow="Legal"><div className="rounded-lg border border-slate-200 bg-white p-6 leading-7 dark:border-slate-800 dark:bg-slate-900">{body}</div></Section>;
}
