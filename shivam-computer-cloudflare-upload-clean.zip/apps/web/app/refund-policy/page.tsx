import { Section } from "@/components/ui";

export const metadata = { title: "Refund Policy" };

export default function RefundPolicyPage() {
  return <Section title="Refund Policy" eyebrow="Legal"><div className="rounded-lg border border-slate-200 bg-white p-6 leading-7 dark:border-slate-800 dark:bg-slate-900">Product refunds follow brand, condition and invoice rules. Course fee refunds depend on admission status, class start date, consumed services and institute policy. Admin can update this policy from website content management.</div></Section>;
}
