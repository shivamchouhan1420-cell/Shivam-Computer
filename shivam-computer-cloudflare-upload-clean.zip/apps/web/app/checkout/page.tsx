import { Section } from "@/components/ui";

export const metadata = { title: "Checkout" };

export default function CheckoutPage() {
  return (
    <Section title="Checkout" eyebrow="Secure order placement">
      <form className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="grid gap-4 rounded-lg border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 md:grid-cols-2">
          {["Full Name", "Mobile", "Email", "City", "State", "PIN Code"].map((label) => <label key={label} className="grid gap-1 text-sm font-semibold">{label}<input className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" /></label>)}
          <label className="grid gap-1 text-sm font-semibold md:col-span-2">Address<textarea className="min-h-28 rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" /></label>
        </div>
        <aside className="h-max rounded-lg border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"><h2 className="font-black">Payment</h2><p className="mt-3 text-sm text-slate-600 dark:text-slate-300">COD, UPI, bank transfer, invoice generation, email notification and order tracking are supported by the backend order API.</p><button className="mt-5 w-full rounded-md bg-river px-4 py-3 font-bold text-white">Place Order</button></aside>
      </form>
    </Section>
  );
}
