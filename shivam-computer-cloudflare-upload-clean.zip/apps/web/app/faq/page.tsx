import { Section } from "@/components/ui";

export const metadata = { title: "FAQ" };

export default function FAQPage() {
  const faqs = ["Do you provide invoices?", "Do courses include certificates?", "Is admission online?", "Do you provide placement support?", "Can I track orders?"];
  return (
    <Section title="FAQ" eyebrow="Common questions">
      <div className="space-y-3">{faqs.map((faq) => <details key={faq} className="rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"><summary className="cursor-pointer font-black">{faq}</summary><p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Yes. The system includes the corresponding frontend screen and backend API support.</p></details>)}</div>
    </Section>
  );
}
