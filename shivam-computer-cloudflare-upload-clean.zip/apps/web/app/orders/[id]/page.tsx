import { PackageCheck } from "lucide-react";
import { Section, Card } from "@/components/ui";

export default async function OrderDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <Section title={`Order ${id}`} eyebrow="Order details">
      <div className="grid gap-5 lg:grid-cols-3">
        {["Order placed", "Payment confirmed", "Packed", "Delivered"].map((step, index) => <Card key={step}><PackageCheck className="h-6 w-6 text-leaf" /><h2 className="mt-3 font-black">{step}</h2><p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{index < 3 ? "Completed" : "Expected soon"}</p></Card>)}
      </div>
    </Section>
  );
}
