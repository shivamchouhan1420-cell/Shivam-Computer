import Link from "next/link";
import { Section } from "@/components/ui";

export const metadata = { title: "Orders" };

export default function OrdersPage() {
  const orders = ["SCM-ORD-1001", "SCM-ORD-1002", "SCM-ORD-1003"];
  return (
    <Section title="Orders" eyebrow="Tracking and invoices">
      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        {orders.map((order, index) => <Link key={order} href={`/orders/${order}`} className="grid gap-2 border-b border-slate-200 p-4 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-950 md:grid-cols-4"><b>{order}</b><span>₹{(12999 + index * 2500).toLocaleString("en-IN")}</span><span>{["Processing", "Shipped", "Delivered"][index]}</span><span>Download invoice</span></Link>)}
      </div>
    </Section>
  );
}
