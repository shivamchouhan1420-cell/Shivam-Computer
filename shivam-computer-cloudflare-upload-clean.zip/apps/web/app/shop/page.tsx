import { productCategories, sampleProducts, brands } from "@scm/shared";
import { SlidersHorizontal } from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { Section } from "@/components/ui";

export const metadata = { title: "Shop" };

export default function ShopPage() {
  return (
    <Section title="Computer Store" eyebrow="Advanced search, filters and sorting">
      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <aside className="h-max rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <h2 className="flex items-center gap-2 font-black"><SlidersHorizontal className="h-5 w-5" /> Filters</h2>
          <input className="mt-4 w-full rounded-md border border-slate-200 bg-transparent px-3 py-3 text-sm dark:border-slate-800" placeholder="Search products" />
          <Filter title="Category" items={productCategories} />
          <Filter title="Brand" items={brands} />
          <Filter title="Rating" items={["4 stars & above", "3 stars & above"]} />
          <Filter title="Price" items={["Under ₹5,000", "₹5,000 - ₹20,000", "Above ₹20,000"]} />
        </aside>
        <div>
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <p className="text-sm font-semibold">{sampleProducts.length} products available with stock tracking, offers, coupons, invoices, reviews, and order tracking.</p>
            <select className="rounded-md border border-slate-200 bg-transparent px-3 py-2 text-sm dark:border-slate-800">
              <option>Sort: Featured</option>
              <option>Price: Low to High</option>
              <option>Price: High to Low</option>
              <option>Rating</option>
            </select>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{sampleProducts.map((product) => <ProductCard key={product.slug} product={product} />)}</div>
        </div>
      </div>
    </Section>
  );
}

function Filter({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="mt-6">
      <h3 className="text-sm font-black">{title}</h3>
      <div className="mt-3 grid gap-2">
        {items.map((item) => <label key={item} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300"><input type="checkbox" /> {item}</label>)}
      </div>
    </div>
  );
}
