import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto grid min-h-[60vh] max-w-2xl place-items-center px-4 text-center">
      <div>
        <p className="text-sm font-black text-river">404 Page</p>
        <h1 className="mt-3 text-4xl font-black">Page not found</h1>
        <p className="mt-3 text-slate-600 dark:text-slate-300">The page may have moved or the link is incorrect.</p>
        <Link href="/" className="mt-6 inline-flex rounded-md bg-ink px-5 py-3 font-bold text-white dark:bg-white dark:text-ink">Back Home</Link>
      </div>
    </div>
  );
}
