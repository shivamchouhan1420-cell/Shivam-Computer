import { courses } from "@scm/shared";
import { Award, Briefcase, CheckCircle2, FlaskConical, HelpCircle } from "lucide-react";
import { notFound } from "next/navigation";
import { ButtonLink, Card, Section } from "@/components/ui";

export function generateStaticParams() {
  return courses.map((course) => ({ slug: course.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const course = courses.find((item) => item.slug === slug);
  return { title: course?.title ?? "Course" };
}

export default async function CourseDetailsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const course = courses.find((item) => item.slug === slug);
  if (!course) notFound();
  return (
    <Section title={course.title} eyebrow="Course Details">
      <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
        <div className="space-y-6">
          <Card><h2 className="text-xl font-black">Overview</h2><p className="mt-3 leading-7 text-slate-600 dark:text-slate-300">{course.overview}</p></Card>
          <Card><h2 className="text-xl font-black">Complete Syllabus</h2><div className="mt-4 grid gap-3 sm:grid-cols-2">{course.syllabus.map((item) => <p key={item} className="flex gap-2 text-sm"><CheckCircle2 className="h-4 w-4 shrink-0 text-leaf" /> {item}</p>)}</div></Card>
          <Card><h2 className="text-xl font-black">Projects and Practical Labs</h2><div className="mt-4 grid gap-3 sm:grid-cols-2">{course.projects.map((item) => <p key={item} className="flex gap-2 text-sm"><FlaskConical className="h-4 w-4 shrink-0 text-river" /> {item}</p>)}</div></Card>
          <Card><h2 className="text-xl font-black">Career Scope</h2><div className="mt-4 grid gap-3 sm:grid-cols-2">{course.careerScope.map((item) => <p key={item} className="flex gap-2 text-sm"><Briefcase className="h-4 w-4 shrink-0 text-saffron" /> {item}</p>)}</div></Card>
          <Card><h2 className="text-xl font-black">FAQ</h2><div className="mt-4 space-y-3">{["Will I get a certificate?", "Are practical labs included?", "Can I apply online?"].map((q) => <details key={q} className="rounded-md border border-slate-200 p-3 dark:border-slate-800"><summary className="cursor-pointer font-semibold"><HelpCircle className="mr-2 inline h-4 w-4" />{q}</summary><p className="mt-2 text-sm text-slate-600 dark:text-slate-300">Yes. The institute provides practical guidance, progress tracking, and certificate support as applicable to the course.</p></details>)}</div></Card>
        </div>
        <aside className="h-max rounded-lg border border-slate-200 bg-white p-6 shadow-premium dark:border-slate-800 dark:bg-slate-900">
          <Award className="h-8 w-8 text-river" />
          <h2 className="mt-4 text-xl font-black">Admission Summary</h2>
          <dl className="mt-4 grid gap-3 text-sm">
            <div className="flex justify-between gap-3"><dt className="text-slate-500">Eligibility</dt><dd className="font-bold text-right">{course.eligibility}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-slate-500">Duration</dt><dd className="font-bold">{course.duration}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-slate-500">Fees</dt><dd className="font-bold">₹{course.fees.toLocaleString("en-IN")}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-slate-500">Certificate</dt><dd className="font-bold">Included</dd></div>
          </dl>
          <ButtonLink href={`/admission?course=${course.slug}`} className="mt-6 w-full bg-river dark:bg-river dark:text-white">Admission Button</ButtonLink>
        </aside>
      </div>
    </Section>
  );
}
