import { courses } from "@scm/shared";
import { CourseCard } from "@/components/course-card";
import { Section } from "@/components/ui";

export const metadata = { title: "Courses" };

export default function CoursesPage() {
  return (
    <Section title="Computer Courses" eyebrow="Nice Computer Institute">
      <p className="mb-8 max-w-3xl leading-7 text-slate-600 dark:text-slate-300">Quality education with practical learning, certification, placement support, career guidance, and affiliation guidance with Makhanlal Chaturvedi National University.</p>
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">{courses.map((course) => <CourseCard key={course.slug} course={course} />)}</div>
    </Section>
  );
}
