import { Section } from "@/components/ui";

export default function ForgotPasswordPage() {
  return (
    <Section title="Forgot Password" eyebrow="OTP verification">
      <form className="mx-auto grid max-w-md gap-4 rounded-lg border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <input className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder="Registered email" />
        <button className="rounded-md bg-ink px-4 py-3 font-bold text-white dark:bg-white dark:text-ink">Send OTP</button>
      </form>
    </Section>
  );
}
