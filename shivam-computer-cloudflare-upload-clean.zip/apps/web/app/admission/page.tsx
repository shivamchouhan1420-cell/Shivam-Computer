import { AdmissionForm } from "@/components/forms";
import { Section } from "@/components/ui";

export const metadata = { title: "Admission" };

export default async function AdmissionPage({ searchParams }: { searchParams: Promise<{ course?: string }> }) {
  const params = await searchParams;
  return (
    <Section title="Online Admission" eyebrow="Student ID, admission number and PDF receipt">
      <p className="mb-8 max-w-3xl leading-7 text-slate-600 dark:text-slate-300">Submit admission details with photo, signature, Aadhaar, qualification and course selection. The backend generates a student ID, admission number, stores the record in MongoDB, and exposes PDF receipt plus Excel export APIs.</p>
      <AdmissionForm selectedCourse={params.course} />
    </Section>
  );
}
