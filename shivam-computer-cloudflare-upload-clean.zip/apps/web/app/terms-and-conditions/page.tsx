import { Section } from "@/components/ui";

export const metadata = { title: "Terms & Conditions" };

export default function TermsPage() {
  return <Section title="Terms & Conditions" eyebrow="Legal"><div className="rounded-lg border border-slate-200 bg-white p-6 leading-7 dark:border-slate-800 dark:bg-slate-900">Use of this platform is subject to accurate information, lawful purchases, course fee policies, warranty terms from brands, and institute rules for attendance, practical labs, assignments and exams.</div></Section>;
}
