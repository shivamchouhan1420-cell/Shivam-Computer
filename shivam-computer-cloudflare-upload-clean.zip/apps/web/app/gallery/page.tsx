import Image from "next/image";
import { Section } from "@/components/ui";

export const metadata = { title: "Gallery" };

const images = [
  "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=900&q=80"
];

export default function GalleryPage() {
  return (
    <Section title="Gallery" eyebrow="Lab, products and events">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{images.map((src, index) => <div key={src} className="relative aspect-[4/3] overflow-hidden rounded-lg shadow-sm"><Image src={src} alt={`Gallery ${index + 1}`} fill className="object-cover" /></div>)}</div>
    </Section>
  );
}
