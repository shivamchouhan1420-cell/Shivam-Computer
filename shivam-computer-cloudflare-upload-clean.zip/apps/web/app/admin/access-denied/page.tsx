import { ShieldAlert } from "lucide-react";
import Link from "next/link";

export default function AdminAccessDeniedPage() {
  return (
    <div className="mx-auto grid min-h-[60vh] max-w-xl place-items-center px-4 text-center">
      <div>
        <ShieldAlert className="mx-auto h-12 w-12 text-red-600" />
        <h1 className="mt-4 text-3xl font-black">Access Denied</h1>
        <p className="mt-3 text-slate-600 dark:text-slate-300">Your account is signed in, but it does not have administrator permissions.</p>
        <Link href="/admin/login" className="mt-6 inline-flex rounded-md bg-ink px-5 py-3 font-bold text-white dark:bg-white dark:text-ink">Back to Admin Login</Link>
      </div>
    </div>
  );
}
