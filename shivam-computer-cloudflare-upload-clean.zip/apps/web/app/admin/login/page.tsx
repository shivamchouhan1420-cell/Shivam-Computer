import { Suspense } from "react";
import { AdminLoginForm } from "@/components/admin-login-form";
import { Section } from "@/components/ui";

export const metadata = { title: "Admin Login" };

export default function AdminLoginPage() {
  return (
    <Section title="Admin Login" eyebrow="Secure role-based access">
      <p className="mx-auto mb-8 max-w-md text-sm leading-6 text-slate-600 dark:text-slate-300">Only shivamchouhan1420@gmail.com can access dashboard, content editing, product management, orders, settings, backups, uploads, and analytics.</p>
      <Suspense fallback={<div className="mx-auto max-w-md rounded-lg border border-slate-200 bg-white p-6 text-sm font-semibold dark:border-slate-800 dark:bg-slate-900">Loading admin login...</div>}>
        <AdminLoginForm />
      </Suspense>
    </Section>
  );
}
