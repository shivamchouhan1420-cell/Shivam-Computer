import { redirect } from "next/navigation";
import { BarChart3, Boxes, FileText, ImageIcon, KeyRound, Settings, ShieldCheck, ShoppingBag, Trash2, Upload, Users } from "lucide-react";
import { AdminLogoutButton } from "@/components/admin-logout-button";
import { Card, Section } from "@/components/ui";
import { getAdminSession } from "@/lib/admin-session";

export const metadata = { title: "Admin Dashboard" };

export default async function AdminPage() {
  const session = await getAdminSession();
  if (session.status === "denied") redirect("/admin/access-denied");

  const permissions = [
    ["Edit any page", FileText],
    ["Add/Edit/Delete products", Boxes],
    ["Change website text", FileText],
    ["Upload images", Upload],
    ["Manage users", Users],
    ["Manage orders", ShoppingBag],
    ["Change prices", KeyRound],
    ["Change banners", ImageIcon],
    ["Edit categories", Boxes],
    ["View analytics", BarChart3],
    ["Change website settings", Settings],
    ["Backup and restore website", ShieldCheck],
    ["Delete any content", Trash2]
  ];

  return (
    <Section title="Admin Dashboard" eyebrow={`Welcome, ${session.user.name}`}>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <div>
          <h2 className="font-black">Role-Based Access Control Active</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">This page is available only after a valid admin JWT is verified by the backend.</p>
        </div>
        <AdminLogoutButton />
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {permissions.map(([permission, Icon]) => (
          <Card key={permission as string}>
            <Icon className="h-6 w-6 text-river" />
            <h3 className="mt-3 font-black">{permission as string}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">Protected by frontend middleware, server role checks, and backend admin-only API middleware.</p>
          </Card>
        ))}
      </div>
    </Section>
  );
}
