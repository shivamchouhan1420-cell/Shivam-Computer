import { Building, Eye, Flag, GraduationCap, Trophy, Users } from "lucide-react";
import { Card, Section } from "@/components/ui";

export const metadata = { title: "About" };

export default function AboutPage() {
  const blocks = [
    ["Company Story", Building], ["Mission", Flag], ["Vision", Eye], ["Achievements", Trophy], ["Infrastructure", Building], ["Faculty", GraduationCap], ["Student Success", Users], ["Our Team", Users]
  ];
  return (
    <Section title="About Shivam Computer Maheshwar" eyebrow="Store and institute">
      <p className="mb-8 max-w-3xl leading-7 text-slate-600 dark:text-slate-300">We combine reliable computer retail, after-sales support, and practical education for students, professionals, homes, and local businesses in Maheshwar.</p>
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">{blocks.map(([title, Icon]) => <Card key={title as string}><Icon className="h-6 w-6 text-river" /><h2 className="mt-3 font-black">{title as string}</h2><p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">Managed from the admin CMS with clean sections for content, images, faculty, success stories and achievements.</p></Card>)}</div>
    </Section>
  );
}
