import { Section } from "@/components/ui";

export default function StudentProfilePage() {
  return (
    <Section title="Student Profile" eyebrow="Profile update">
      <form className="grid gap-4 rounded-lg border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 md:grid-cols-2">
        {["Name", "Mobile", "WhatsApp", "Email", "Address", "Qualification"].map((label) => <label key={label} className="grid gap-1 text-sm font-semibold">{label}<input className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" /></label>)}
        <button className="rounded-md bg-ink px-4 py-3 font-bold text-white dark:bg-white dark:text-ink md:col-span-2">Update Profile</button>
      </form>
    </Section>
  );
}
