import { contactInfo } from "@scm/shared";
import type { Metadata } from "next";
import { Toaster } from "sonner";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { FloatingWhatsApp } from "@/components/floating-whatsapp";
import { Providers } from "@/components/providers";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Shivam Computer Maheshwar",
    template: "%s | Shivam Computer Maheshwar"
  },
  description: "Your trusted computer store and computer training institute in Maheshwar.",
  openGraph: {
    title: "Shivam Computer Maheshwar",
    description: "Premium computer products, practical computer education, admissions, and student services.",
    type: "website"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Shivam Computer Maheshwar",
    telephone: contactInfo.phone,
    email: contactInfo.email,
    address: [
      {
        "@type": "PostalAddress",
        streetAddress: "MG Road, Near Gurudwara",
        addressLocality: "Maheshwar",
        addressRegion: "Madhya Pradesh",
        postalCode: "451224",
        addressCountry: "IN"
      },
      {
        "@type": "PostalAddress",
        streetAddress: "27, Teacher Colony",
        addressLocality: "Maheshwar",
        addressRegion: "Madhya Pradesh",
        postalCode: "451224",
        addressCountry: "IN"
      }
    ],
    contactPoint: {
      "@type": "ContactPoint",
      telephone: contactInfo.phone,
      contactType: "customer service",
      email: contactInfo.email,
      areaServed: "IN",
      availableLanguage: ["en", "hi"]
    },
    sameAs: [contactInfo.whatsappLink]
  };

  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <Providers>
          <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }} />
          <Header />
          <main>{children}</main>
          <FloatingWhatsApp />
          <Footer />
          <Toaster richColors position="top-right" />
        </Providers>
      </body>
    </html>
  );
}
