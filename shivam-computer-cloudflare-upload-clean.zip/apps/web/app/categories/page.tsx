import { productCategories } from "@scm/shared";
import Link from "next/link";
import { Section } from "@/components/ui";

export const metadata = { title: "Categories" };

export default function CategoriesPage() {
  return (
    <Section title="Product Categories" eyebrow="Complete computer store">
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
        {productCategories.map((category) => <Link key={category} href={`/categories/${category.toLowerCase().replaceAll(" ", "-")}`} className="rounded-lg border border-slate-200 bg-white p-5 font-black shadow-sm hover:border-river dark:border-slate-800 dark:bg-slate-900">{category}</Link>)}
      </div>
    </Section>
  );
}
