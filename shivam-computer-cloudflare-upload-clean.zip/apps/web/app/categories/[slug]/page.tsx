import { sampleProducts, productCategories } from "@scm/shared";
import { notFound } from "next/navigation";
import { ProductCard } from "@/components/product-card";
import { Section } from "@/components/ui";

export function generateStaticParams() {
  return productCategories.map((category) => ({ slug: category.toLowerCase().replaceAll(" ", "-") }));
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const category = productCategories.find((item) => item.toLowerCase().replaceAll(" ", "-") === slug);
  if (!category) notFound();
  const products = sampleProducts.filter((product) => product.category === category);
  return (
    <Section title={category} eyebrow="Category">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{products.map((product) => <ProductCard key={product.slug} product={product} />)}</div>
    </Section>
  );
}
