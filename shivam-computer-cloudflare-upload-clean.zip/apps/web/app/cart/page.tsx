import { sampleProducts } from "@scm/shared";
import { Minus, Plus, Trash2 } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { Section } from "@/components/ui";

export const metadata = { title: "Cart" };

export default function CartPage() {
  const cart = sampleProducts.slice(0, 3);
  const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
  return (
    <Section title="Cart" eyebrow="Review products">
      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="space-y-4">{cart.map((item) => <div key={item.slug} className="grid gap-4 rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 sm:grid-cols-[110px_1fr_auto]"><div className="relative aspect-square overflow-hidden rounded-md"><Image src={item.image} alt={item.name} fill className="object-cover" /></div><div><h2 className="font-black">{item.name}</h2><p className="mt-1 text-sm text-slate-500">{item.offer}</p><p className="mt-3 text-lg font-black">₹{item.price.toLocaleString("en-IN")}</p></div><div className="flex items-center gap-2"><button className="grid h-9 w-9 place-items-center rounded-md border"><Minus className="h-4 w-4" /></button><span className="font-bold">1</span><button className="grid h-9 w-9 place-items-center rounded-md border"><Plus className="h-4 w-4" /></button><button className="grid h-9 w-9 place-items-center rounded-md border"><Trash2 className="h-4 w-4" /></button></div></div>)}</div>
        <aside className="h-max rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900"><h2 className="font-black">Order Summary</h2><div className="mt-4 space-y-3 text-sm"><p className="flex justify-between"><span>Subtotal</span><b>₹{subtotal.toLocaleString("en-IN")}</b></p><p className="flex justify-between"><span>Coupon</span><b>SCM500</b></p><p className="flex justify-between"><span>Total</span><b>₹{(subtotal - 500).toLocaleString("en-IN")}</b></p></div><Link className="mt-5 block rounded-md bg-ink px-4 py-3 text-center font-bold text-white dark:bg-white dark:text-ink" href="/checkout">Checkout</Link></aside>
      </div>
    </Section>
  );
}
