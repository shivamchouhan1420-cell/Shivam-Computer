import { brands, contactInfo, courses, productCategories, sampleProducts } from "@scm/shared";
import { ArrowRight, BadgeCheck, BookOpen, Building2, MessageCircle, ShieldCheck, Sparkles, Users } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { CourseCard } from "@/components/course-card";
import { ProductCard } from "@/components/product-card";
import { ButtonLink, Card, Section } from "@/components/ui";

export default function HomePage() {
  return (
    <>
      <section className="relative overflow-hidden bg-white dark:bg-slate-950">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(14,165,233,.18),transparent_26%),radial-gradient(circle_at_80%_10%,rgba(245,158,11,.16),transparent_28%),linear-gradient(135deg,rgba(22,163,74,.08),transparent_45%)]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_0.9fr] lg:px-8">
          <div>
            <p className="inline-flex rounded-md bg-river/10 px-3 py-2 text-sm font-bold text-river">Your Trusted Computer Store & Computer Training Institute</p>
            <h1 className="mt-5 max-w-3xl text-4xl font-black leading-tight text-ink dark:text-white sm:text-6xl">Shivam Computer Maheshwar</h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-600 dark:text-slate-300">Buy genuine computers, accessories, software, and join practical computer courses with certification, placement support, and career guidance.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ButtonLink href="/shop">Shop Now <ArrowRight className="ml-2 h-4 w-4" /></ButtonLink>
              <ButtonLink href="/admission" className="bg-river dark:bg-river dark:text-white">Apply Admission</ButtonLink>
            </div>
          </div>
          <div className="relative aspect-[5/4] overflow-hidden rounded-lg shadow-premium">
            <Image src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=85" alt="Computer training lab" fill priority className="object-cover" />
          </div>
        </div>
      </section>

      <section className="bg-slate-950 py-8 text-white">
        <div className="mx-auto grid max-w-7xl gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-8">
          {[["5000+", "Happy customers"], ["1200+", "Trained students"], ["18", "Product categories"], ["16", "Career courses"]].map(([value, label]) => (
            <div key={label} className="rounded-lg border border-white/10 p-5">
              <div className="text-3xl font-black">{value}</div>
              <div className="text-sm text-slate-300">{label}</div>
            </div>
          ))}
        </div>
      </section>

      <Section title="Featured Products" eyebrow="Computer Store">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{sampleProducts.slice(0, 8).map((product) => <ProductCard key={product.slug} product={product} />)}</div>
      </Section>

      <Section title="Top Categories" eyebrow="Shop by need">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">{productCategories.map((category) => <Link key={category} href={`/categories/${category.toLowerCase().replaceAll(" ", "-")}`} className="rounded-lg border border-slate-200 bg-white p-4 text-sm font-bold shadow-sm hover:border-river dark:border-slate-800 dark:bg-slate-900">{category}</Link>)}</div>
      </Section>

      <Section title="Featured Courses" eyebrow="Nice Computer Institute">
        <div className="mb-6 rounded-lg bg-river/10 p-5 text-sm leading-6 text-slate-700 dark:text-slate-200">Professional institute section with quality education, practical labs, certification guidance, placement support, and career counseling. Affiliation guidance: Makhanlal Chaturvedi National University.</div>
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">{courses.slice(0, 8).map((course) => <CourseCard key={course.slug} course={course} />)}</div>
      </Section>

      <Section title="Why Choose Us" eyebrow="Trust and service">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {[["Genuine Products", ShieldCheck], ["Practical Learning", BookOpen], ["Career Guidance", Users], ["Local Support", BadgeCheck]].map(([title, Icon]) => (
            <Card key={title as string}><Icon className="h-7 w-7 text-river" /><h3 className="mt-4 font-black">{title as string}</h3><p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">Clear advice, transparent pricing, and after-service support for students, homes, and businesses.</p></Card>
          ))}
        </div>
      </Section>

      <Section title="Testimonials, Gallery and Brands" eyebrow="Community">
        <div className="grid gap-5 lg:grid-cols-3">
          {["Best place for laptop purchase and setup.", "DCA practical classes helped me get office confidence.", "Fast repair support and honest product suggestions."].map((quote) => <Card key={quote}><Sparkles className="h-5 w-5 text-saffron" /><p className="mt-4 text-sm leading-6">{quote}</p></Card>)}
        </div>
        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">{brands.map((brand) => <div key={brand} className="rounded-lg border border-slate-200 bg-white p-4 text-center text-sm font-black dark:border-slate-800 dark:bg-slate-900">{brand}</div>)}</div>
        <div className="mt-8 grid gap-5 lg:grid-cols-2">
          <Card><Building2 className="h-6 w-6 text-leaf" /><h3 className="mt-3 font-black">University Logos</h3><p className="mt-2 text-sm text-slate-600 dark:text-slate-300">Makhanlal Chaturvedi National University affiliation information and academic guidance can be managed from admin settings.</p></Card>
          <Card><MessageCircle className="h-6 w-6 text-river" /><h3 className="mt-3 font-black">Contact Preview</h3><p className="mt-2 text-sm text-slate-600 dark:text-slate-300">Call or WhatsApp {contactInfo.phone}, email {contactInfo.email}, visit during business hours, or submit the contact form for quick help.</p></Card>
        </div>
      </Section>
    </>
  );
}
