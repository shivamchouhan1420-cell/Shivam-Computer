import { Award, BookOpen, ClipboardCheck, CreditCard, FileDown, UserRound } from "lucide-react";
import { Card, Section } from "@/components/ui";

export const metadata = { title: "Student Dashboard" };

export default function StudentDashboardPage() {
  const items = ["Profile", "Admission Status", "Course Details", "Study Material", "Attendance", "Assignments", "Exam", "Result", "Certificate", "Fee Status", "Payment History", "Download Receipt"];
  const icons = [UserRound, ClipboardCheck, BookOpen, BookOpen, ClipboardCheck, BookOpen, ClipboardCheck, Award, Award, CreditCard, CreditCard, FileDown];
  return (
    <Section title="Student Dashboard" eyebrow="Learning and admission portal">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{items.map((item, index) => { const Icon = icons[index]; return <Card key={item}><Icon className="h-6 w-6 text-river" /><h2 className="mt-3 font-black">{item}</h2><p className="mt-2 text-sm text-slate-600 dark:text-slate-300">View, update and download from your student account.</p></Card>; })}</div>
    </Section>
  );
}
