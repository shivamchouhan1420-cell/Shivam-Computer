import { contactInfo } from "@scm/shared";
import { Mail, MapPin, MessageCircle, Phone, type LucideIcon } from "lucide-react";
import { Card, Section } from "@/components/ui";

export const metadata = {
  title: "Contact",
  description: `Call or WhatsApp ${contactInfo.phone}, email ${contactInfo.email}, or visit Shivam Computer Maheshwar at ${contactInfo.address1} or ${contactInfo.address2}.`
};

export default function ContactPage() {
  const contactCards: { title: string; text: string; Icon: LucideIcon; href?: string }[] = [
    { title: "Phone", text: contactInfo.phone, Icon: Phone, href: contactInfo.callLink },
    { title: "WhatsApp", text: contactInfo.whatsapp, Icon: MessageCircle, href: contactInfo.whatsappLink },
    { title: "Email", text: contactInfo.email, Icon: Mail, href: `mailto:${contactInfo.email}` },
    { title: "Address 1", text: contactInfo.address1, Icon: MapPin },
    { title: "Address 2", text: contactInfo.address2, Icon: MapPin }
  ];

  return (
    <Section title="Contact" eyebrow="Visit, call or WhatsApp">
      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <form className="grid gap-4 rounded-lg border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          {["Name", "Mobile", "Email", "Subject"].map((label) => <input key={label} className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder={label} />)}
          <textarea className="min-h-32 rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder="Message" />
          <button className="rounded-md bg-river px-4 py-3 font-bold text-white">Send Message</button>
        </form>
        <div className="space-y-4">
          {contactCards.map(({ title, text, Icon, href }) => <Card key={title}><Icon className="h-6 w-6 text-river" /><h2 className="mt-3 font-black">{title}</h2><p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{href ? <a href={href}>{text}</a> : text}</p></Card>)}
          <div className="aspect-[16/9] rounded-lg border border-slate-200 bg-slate-100 p-5 text-sm font-semibold dark:border-slate-800 dark:bg-slate-900">Google Map embed ready for MG Road, Near Gurudwara and Teacher Colony, Maheshwar.</div>
        </div>
      </div>
    </Section>
  );
}
