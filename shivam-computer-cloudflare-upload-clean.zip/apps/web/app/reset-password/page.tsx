import { Section } from "@/components/ui";

export default function ResetPasswordPage() {
  return (
    <Section title="Reset Password" eyebrow="Secure reset">
      <form className="mx-auto grid max-w-md gap-4 rounded-lg border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <input className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder="OTP" />
        <input className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder="New password" type="password" />
        <button className="rounded-md bg-river px-4 py-3 font-bold text-white">Reset Password</button>
      </form>
    </Section>
  );
}
