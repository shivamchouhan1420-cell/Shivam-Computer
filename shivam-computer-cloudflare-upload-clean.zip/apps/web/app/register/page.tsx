import { Section } from "@/components/ui";

export const metadata = { title: "Register" };

export default function RegisterPage() {
  return (
    <Section title="Register" eyebrow="Email and OTP verification ready">
      <form className="mx-auto grid max-w-md gap-4 rounded-lg border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        {["Name", "Email", "Mobile", "Password"].map((item) => <input key={item} type={item === "Password" ? "password" : "text"} className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder={item} />)}
        <button className="rounded-md bg-river px-4 py-3 font-bold text-white">Create Account</button>
      </form>
    </Section>
  );
}
