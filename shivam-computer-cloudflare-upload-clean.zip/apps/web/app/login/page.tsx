import Link from "next/link";
import { Section } from "@/components/ui";

export const metadata = { title: "Login" };

export default function LoginPage() {
  return <AuthForm title="Login" button="Login" extra={<><Link href="/forgot-password">Forgot password?</Link><Link href="/register">Create account</Link></>} />;
}

function AuthForm({ title, button, extra }: { title: string; button: string; extra: React.ReactNode }) {
  return (
    <Section title={title} eyebrow="JWT authentication">
      <form className="mx-auto grid max-w-md gap-4 rounded-lg border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <input className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder="Email" />
        <input className="rounded-md border border-slate-200 bg-transparent px-3 py-3 dark:border-slate-800" placeholder="Password" type="password" />
        <button className="rounded-md bg-ink px-4 py-3 font-bold text-white dark:bg-white dark:text-ink">{button}</button>
        <div className="flex justify-between text-sm font-semibold text-river">{extra}</div>
      </form>
    </Section>
  );
}
