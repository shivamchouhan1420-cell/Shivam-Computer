import { courses, productCategories, sampleProducts } from "@scm/shared";
import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://shivamcomputer.in";
  const staticPages = ["", "shop", "categories", "courses", "admission", "about", "gallery", "testimonials", "blog", "faq", "privacy-policy", "terms-and-conditions", "refund-policy", "contact"];
  return [
    ...staticPages.map((page) => ({ url: `${base}/${page}`, lastModified: new Date() })),
    ...courses.map((course) => ({ url: `${base}/courses/${course.slug}`, lastModified: new Date() })),
    ...productCategories.map((category) => ({ url: `${base}/categories/${category.toLowerCase().replaceAll(" ", "-")}`, lastModified: new Date() })),
    ...sampleProducts.map((product) => ({ url: `${base}/products/${product.slug}`, lastModified: new Date() }))
  ];
}
