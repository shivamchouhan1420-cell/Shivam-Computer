import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { apiBase } from "@/lib/api";
import { adminCookieName } from "@/lib/admin-constants";

export type AdminSession =
  | { status: "authorized"; user: { id: string; name: string; email: string; role: "admin" } }
  | { status: "denied" };

export async function getAdminSession(): Promise<AdminSession> {
  const cookieStore = await cookies();
  const token = cookieStore.get(adminCookieName)?.value;
  if (!token) redirect("/admin/login");

  const response = await fetch(`${apiBase}/auth/me`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store"
  });

  if (response.status === 401) redirect("/admin/login");
  if (!response.ok) return { status: "denied" };

  const data = await response.json();
  if (data.user?.role !== "admin" || data.user?.email !== "shivamchouhan1420@gmail.com") return { status: "denied" };

  return { status: "authorized", user: data.user };
}
