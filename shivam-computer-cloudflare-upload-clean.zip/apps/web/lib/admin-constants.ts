export const adminCookieName = "scm_admin_token";
