# Shivam Computer Maheshwar

Production-ready full-stack starter for a premium computer store and computer training institute.

## Apps

- `apps/web`: Next.js, TypeScript, Tailwind CSS, React Query, Framer Motion.
- `apps/api`: Express.js, TypeScript, MongoDB/Mongoose, JWT auth, RBAC, Cloudinary-ready uploads.
- `packages/shared`: shared catalog, courses, and navigation data.

## Quick Start

```bash
pnpm install
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env.local
pnpm seed
pnpm dev
```

Frontend: `http://localhost:3000`

Backend: `http://localhost:5001/api`

## MongoDB

The API needs MongoDB before `reset-admin`, `seed`, or `dev` will work. The default local URI is:

```bash
mongodb://127.0.0.1:27017/shivam-computer-maheshwar
```

If Docker is installed, start MongoDB with:

```bash
docker compose up -d mongo
pnpm --filter @scm/api reset-admin
pnpm --filter @scm/api dev
```

If you use MongoDB Atlas, put your connection string in `apps/api/.env`:

```bash
MONGODB_URI=mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/shivam-computer-maheshwar
```

## Default Seed Users

- Sole admin email: `shivamchouhan1420@gmail.com`
- Demo user: `student@shivamcomputer.in` / `Student@12345`

Admin access is granted only to the user record with email `shivamchouhan1420@gmail.com`. Run `pnpm --filter @scm/api reset-admin` to demote all other accounts to `user` and promote that email to `admin` if it exists.
If the account does not exist, the reset script creates it and stores a bcrypt hash for the bootstrap password.

## Admin Access

- Admin login page: `/admin/login`
- Protected dashboard: `/admin`
- Visitors without the secure admin cookie are redirected to `/admin/login`.
- Non-admin JWTs and admin-role JWTs for any other email are rejected by the server-side dashboard check and by backend RBAC middleware.
- Admin-only backend actions include product/category/content mutation, user management, orders, admissions, analytics, uploads, backup, restore, settings, banners, and deletes.

## Deployment

- Frontend: Cloudflare Workers deployment for `apps/web`, install command `pnpm install --frozen-lockfile`, build command `pnpm --filter @scm/web cf:build`, deploy command `pnpm --filter @scm/web cf:deploy`.
- Backend: Render/Railway monorepo deployment, build command `pnpm install --frozen-lockfile && pnpm --filter @scm/api build`, start command `pnpm --filter @scm/api start`.

Set `MONGODB_URI`, `JWT_SECRET`, `CLIENT_URL`, SMTP credentials, and Cloudinary credentials in production.
Set `NEXT_PUBLIC_API_URL` for the Cloudflare Worker frontend so it can reach the backend API.
See `CLOUDFLARE_DEPLOYMENT.md` for complete Cloudflare setup notes.
