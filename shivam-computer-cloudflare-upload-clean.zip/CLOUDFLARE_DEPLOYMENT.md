# Cloudflare Deployment

This project is now prepared to deploy the Next.js frontend (`apps/web`) to Cloudflare Workers with the OpenNext Cloudflare adapter.

## Frontend: Cloudflare Workers

Run from the repository root:

```bash
pnpm install
pnpm cf:build
pnpm cf:preview
pnpm cf:deploy
```

The Cloudflare Worker config lives in `apps/web/wrangler.jsonc`.

Before production deploy, update this value in `apps/web/wrangler.jsonc` or in Cloudflare dashboard environment variables:

```bash
NEXT_PUBLIC_API_URL=https://your-api-domain.com/api
```

For local Cloudflare preview, copy:

```bash
cp apps/web/.dev.vars.example apps/web/.dev.vars
```

Then edit `apps/web/.dev.vars` if your API URL is different.

## Cloudflare Dashboard Settings

Use these monorepo settings:

- Root directory: repository root
- Install command: `pnpm install --frozen-lockfile`
- Build command: `pnpm --filter @scm/web cf:build`
- Deploy command: `pnpm --filter @scm/web cf:deploy`
- Node.js version: `22`

## Backend API

The current backend (`apps/api`) is an Express + Mongoose server. That server should run on a Node hosting service or container platform, then be proxied through Cloudflare DNS.

Good production options:

- Render, Railway, Fly.io, or a VPS for the existing Express API
- MongoDB Atlas for the database
- Cloudflare DNS + SSL in front of the API domain

Set these backend environment variables in the API host:

```bash
MONGODB_URI=mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/shivam-computer-maheshwar
JWT_SECRET=replace-with-a-long-random-secret
CLIENT_URL=https://your-cloudflare-worker-domain
ADMIN_EMAIL=shivamchouhan1420@gmail.com
ADMIN_BOOTSTRAP_PASSWORD=Admin@12345
```

## Full Cloudflare-Native Option

If you want every backend service on Cloudflare too, the API needs a separate migration from Express/Mongoose to a Workers-compatible API layer and a Cloudflare-compatible database/storage plan:

- API runtime: Cloudflare Workers, Hono, or Worker route handlers
- Database: Cloudflare D1, Hyperdrive with a managed SQL database, or an external MongoDB HTTP-compatible data API
- Upload storage: Cloudflare R2
- Scheduled backup jobs: Cloudflare Cron Triggers

That is a larger backend migration. The current setup keeps the existing Node/Mongo API working and makes the frontend Cloudflare-ready immediately.
