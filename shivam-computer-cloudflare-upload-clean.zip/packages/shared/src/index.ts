export const productCategories = [
  "Desktop",
  "Laptop",
  "Gaming PC",
  "Printer",
  "Monitor",
  "Keyboard",
  "Mouse",
  "SSD",
  "RAM",
  "Hard Disk",
  "Pendrive",
  "Graphics Card",
  "UPS",
  "Router",
  "Networking",
  "Software",
  "Antivirus",
  "Accessories"
];

export const brands = [
  "HP",
  "Dell",
  "Lenovo",
  "Asus",
  "Acer",
  "Canon",
  "Epson",
  "Logitech",
  "TP-Link",
  "Microsoft",
  "Quick Heal",
  "Tally"
];

export const courses = [
  {
    slug: "dca",
    title: "DCA",
    duration: "12 months",
    fees: 12000,
    eligibility: "10th or 12th pass",
    overview: "Diploma in Computer Applications focused on office productivity, programming basics, internet skills, and practical computer operations.",
    syllabus: ["Computer fundamentals", "Windows and file management", "MS Office", "Internet and email", "HTML basics", "Database basics", "Project work"],
    projects: ["Digital office portfolio", "Student database mini project"],
    careerScope: ["Computer operator", "Office assistant", "Data entry executive"]
  },
  {
    slug: "pgdca",
    title: "PGDCA",
    duration: "12 months",
    fees: 18000,
    eligibility: "Graduation in any stream",
    overview: "Post Graduate Diploma in Computer Applications with practical software, database, web, and programming training.",
    syllabus: ["IT fundamentals", "Programming with C", "DBMS", "Web design", "Software engineering", "Tally basics", "Major project"],
    projects: ["Business website", "Inventory database"],
    careerScope: ["Junior developer", "MIS executive", "IT support executive"]
  },
  {
    slug: "basic-computer",
    title: "Basic Computer",
    duration: "3 months",
    fees: 3500,
    eligibility: "Open for all learners",
    overview: "A beginner-friendly practical course covering computer operations, typing, internet, email, and office work.",
    syllabus: ["Computer basics", "Typing practice", "MS Word", "MS Excel", "PowerPoint", "Internet use", "Online forms"],
    projects: ["Resume creation", "Household budget sheet"],
    careerScope: ["Office assistant", "Front desk operator"]
  },
  {
    slug: "cpct",
    title: "CPCT",
    duration: "4 months",
    fees: 5000,
    eligibility: "12th pass",
    overview: "Focused preparation for CPCT with typing speed, computer knowledge, Hindi/English practice, and mock tests.",
    syllabus: ["Computer awareness", "Hindi typing", "English typing", "Reasoning", "Mock tests", "Speed improvement"],
    projects: ["Timed typing portfolio", "CPCT test simulator practice"],
    careerScope: ["Government computer posts", "Data entry roles"]
  },
  {
    slug: "tally-prime-with-gst",
    title: "Tally Prime with GST",
    duration: "3 months",
    fees: 7000,
    eligibility: "Commerce basics recommended",
    overview: "Accounting course covering Tally Prime, GST, inventory, payroll, banking, and reports.",
    syllabus: ["Company creation", "Ledgers", "Vouchers", "GST billing", "Inventory", "Payroll", "Reports"],
    projects: ["GST invoice book", "Full accounting case study"],
    careerScope: ["Account assistant", "Billing executive", "Tally operator"]
  },
  {
    slug: "ms-office",
    title: "MS Office",
    duration: "2 months",
    fees: 3000,
    eligibility: "Open for all learners",
    overview: "Practical office course for Word, Excel, PowerPoint, forms, reports, and business documents.",
    syllabus: ["MS Word", "MS Excel", "PowerPoint", "Mail merge", "Charts", "Printing"],
    projects: ["Business report", "Presentation deck"],
    careerScope: ["Office executive", "Documentation assistant"]
  },
  {
    slug: "advanced-excel",
    title: "Advanced Excel",
    duration: "2 months",
    fees: 4500,
    eligibility: "Basic Excel knowledge",
    overview: "Data-focused Excel course for formulas, dashboards, pivots, lookup functions, and reports.",
    syllabus: ["Advanced formulas", "Pivot tables", "Dashboards", "Data validation", "Charts", "MIS reports"],
    projects: ["Sales dashboard", "Attendance tracker"],
    careerScope: ["MIS executive", "Data assistant"]
  },
  {
    slug: "typing",
    title: "Typing",
    duration: "2 months",
    fees: 2500,
    eligibility: "Open for all learners",
    overview: "Hindi and English typing course for speed, accuracy, government exam preparation, and daily practice.",
    syllabus: ["Keyboard layout", "English typing", "Hindi typing", "Speed drills", "Accuracy tests"],
    projects: ["Timed speed records", "Typing certificate test"],
    careerScope: ["Data entry", "CPCT preparation"]
  },
  {
    slug: "photoshop",
    title: "Photoshop",
    duration: "3 months",
    fees: 6500,
    eligibility: "Basic computer knowledge",
    overview: "Graphic design course for image editing, posters, social media creatives, and print-ready layouts.",
    syllabus: ["Tools", "Layers", "Retouching", "Poster design", "Social media design", "Print export"],
    projects: ["Poster set", "Photo retouching portfolio"],
    careerScope: ["Graphic designer", "Photo editor"]
  },
  {
    slug: "coreldraw",
    title: "CorelDRAW",
    duration: "3 months",
    fees: 6500,
    eligibility: "Basic computer knowledge",
    overview: "Vector design course for logos, visiting cards, banners, flex boards, and print design.",
    syllabus: ["Vector tools", "Typography", "Logo design", "Visiting cards", "Banner design", "Print setup"],
    projects: ["Brand identity kit", "Flex banner"],
    careerScope: ["Print designer", "DTP operator"]
  },
  {
    slug: "web-design",
    title: "Web Design",
    duration: "6 months",
    fees: 12000,
    eligibility: "Basic computer knowledge",
    overview: "Website design course covering HTML, CSS, JavaScript, responsive layouts, hosting, and projects.",
    syllabus: ["HTML", "CSS", "JavaScript", "Responsive design", "Bootstrap/Tailwind", "Hosting"],
    projects: ["Portfolio website", "Business landing page"],
    careerScope: ["Web designer", "Frontend trainee"]
  },
  {
    slug: "python",
    title: "Python",
    duration: "4 months",
    fees: 9000,
    eligibility: "Basic computer knowledge",
    overview: "Programming course covering Python fundamentals, automation, data handling, and practical scripts.",
    syllabus: ["Syntax", "Control flow", "Functions", "Files", "OOP", "Mini automation", "Project"],
    projects: ["Billing script", "Student marks analyzer"],
    careerScope: ["Python trainee", "Automation assistant"]
  },
  {
    slug: "java",
    title: "Java",
    duration: "5 months",
    fees: 10000,
    eligibility: "Programming basics helpful",
    overview: "Core Java course covering OOP, collections, file handling, JDBC basics, and projects.",
    syllabus: ["OOP", "Classes", "Collections", "Exceptions", "Files", "JDBC", "Project"],
    projects: ["Library system", "Billing application"],
    careerScope: ["Java trainee", "Backend trainee"]
  },
  {
    slug: "c",
    title: "C",
    duration: "3 months",
    fees: 5000,
    eligibility: "Open for beginners",
    overview: "Foundational programming course with C syntax, logic building, arrays, pointers, and file basics.",
    syllabus: ["C basics", "Loops", "Arrays", "Functions", "Pointers", "Files"],
    projects: ["Calculator", "Marks management"],
    careerScope: ["Programming foundation", "College preparation"]
  },
  {
    slug: "cpp",
    title: "C++",
    duration: "3 months",
    fees: 6000,
    eligibility: "C basics helpful",
    overview: "Object-oriented programming course with C++ classes, inheritance, polymorphism, STL, and projects.",
    syllabus: ["C++ basics", "OOP", "Inheritance", "Polymorphism", "Templates", "STL"],
    projects: ["Banking system", "Inventory console app"],
    careerScope: ["Programming foundation", "Software trainee"]
  },
  {
    slug: "digital-marketing",
    title: "Digital Marketing",
    duration: "4 months",
    fees: 9000,
    eligibility: "Open for all learners",
    overview: "Practical digital marketing course covering SEO, social media, ads, analytics, content, and campaigns.",
    syllabus: ["SEO", "Social media", "Google Ads", "Meta Ads", "Analytics", "Content planning"],
    projects: ["Local SEO plan", "Social campaign calendar"],
    careerScope: ["Digital marketing executive", "Social media assistant"]
  }
];

export const sampleProducts = productCategories.map((category, index) => ({
  slug: category.toLowerCase().replaceAll(" ", "-"),
  name: `${category} Pro Select ${index + 1}`,
  category,
  brand: brands[index % brands.length],
  price: 2499 + index * 1750,
  mrp: 3499 + index * 2100,
  discount: 12 + (index % 6) * 3,
  rating: 4 + (index % 10) / 10,
  stock: 8 + index,
  sku: `SCM-${category.slice(0, 3).toUpperCase()}-${1000 + index}`,
  offer: index % 2 === 0 ? "Free setup support" : "Student special price",
  image: `https://images.unsplash.com/photo-${index % 3 === 0 ? "1517336714731-489689fd1ca8" : index % 3 === 1 ? "1593640408182-31c70c8268f5" : "1588872657578-7efd1f1555ed"}?auto=format&fit=crop&w=900&q=80`,
  description: `Reliable ${category.toLowerCase()} solution with genuine warranty, local support, and expert installation from Shivam Computer Maheshwar.`,
  specifications: {
    warranty: "1 year",
    support: "On-site guidance available",
    condition: "New"
  }
}));

export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  { href: "/courses", label: "Courses" },
  { href: "/admission", label: "Admission" },
  { href: "/about", label: "About" },
  { href: "/blog", label: "Blog" },
  { href: "/contact", label: "Contact" }
];

export const contactInfo = {
  phone: "+91 9893096136",
  whatsapp: "+91 9893096136",
  whatsappLink: "https://wa.me/919893096136",
  callLink: "tel:+919893096136",
  email: "nicecomputer8513mhs@gmail.com",
  address1: "MG Road, Near Gurudwara, Maheshwar, Madhya Pradesh 451224, India",
  address2: "27, Teacher Colony, Maheshwar, Madhya Pradesh 451224, India"
};
